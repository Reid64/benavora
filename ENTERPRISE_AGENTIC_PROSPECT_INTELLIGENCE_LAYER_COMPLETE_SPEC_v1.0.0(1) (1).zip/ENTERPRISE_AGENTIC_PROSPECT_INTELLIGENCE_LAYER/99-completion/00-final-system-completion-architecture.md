# PIL Specification Completion Architecture

**Release:** PIL-COMPLETE-SPEC-v1.0.0  
**Canonical agents:** 44  
**Canonical deterministic services:** 30  
**Specification state:** COMPLETE  
**Runtime implementation state:** NOT CLAIMED  
**Production readiness:** NOT CLAIMED

## Closed-loop operating model

DISCOVER → RESOLVE → RESEARCH → VERIFY → CONNECT → REASON → QUALIFY → PRIORITIZE → STRATEGIZE → SYNCHRONIZE → MONITOR → OBSERVE OUTCOMES → LEARN → REPLAN.

The PIL remains an intelligence and decision layer. Evidence truth, canonical graph truth, opportunity intelligence, and CRM operational state are distinct stores.

## Fleet completion

- Supervisory: 6/6 specified.
- Discovery: 8/8 specified.
- Intelligence: 10/10 specified.
- Relationship: 6/6 specified.
- Qualification: 5/5 specified.
- Strategy: 4/4 specified.
- Knowledge Integrity: 4/4 specified.
- Operations/Evaluation/Learning: 1/1 specified.
- Total: 44/44 specified.

## Agent-versus-service classification

A component is an agent only when it durably owns/receives a goal, observes state, plans, selects among authorized actions, executes/delegates, evaluates evidence/results, replans, persists across failure, and produces reconstructable decisions. Mechanical infrastructure remains deterministic.

## Architecture invariants

1. Tenant context is derived from authenticated identity and enforced at every data/control plane boundary.
2. Every consequential claim is evidence-linked and epistemically classified.
3. Consequential self-certification is forbidden; independent critic context is required.
4. Child delegation never increases authority.
5. Mutations are idempotent and optimistic-concurrency controlled.
6. Workflows assume workers and model sessions can die at any time.
7. Learning is proposal-driven, versioned, reversible, evaluated, and unable to weaken policy/security.
8. Budgets are hard constraints, not reporting fields.
9. Prompt/source content is untrusted data and cannot issue instructions to the agent runtime.
10. No production-ready label is allowed without executed G0–G5 evidence and ≥95/100 independent score.

## Downstream Corporate Application Automation boundary

The separately requested Corporate Funding, Grant, and In-Kind Contribution Application Automation System is a downstream execution subsystem. It may consume qualified PIL opportunities and return application outcomes/learning signals. It does not change the PIL's canonical intelligence ownership or justify converting account registration, email confirmation, credential storage, browser field entry, screenshots, queues, retries, uploads, or CRM synchronization into agents.

Any genuinely new application-execution agent must be justified by a separate overlap/ownership analysis and appended through a new canonical registry version rather than silently changing this completed 44-agent PIL fleet.
