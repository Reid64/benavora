# ARCHITECTURE_POST_BUILD — Complete System Design After PIL Full Build
**Date:** 2026-09-01 | **Status:** DEPLOYED | **Scope:** Full Benavora platform + PIL

## HIGH-LEVEL SYSTEM DIAGRAM

```
┌─────────────────────────────────────────────────────────────────┐
│                        BENAVORA PLATFORM                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  FRONTEND (Next.js 15, Vercel)                                  │
│  ├─ Dashboard                                                   │
│  │  ├─ Opportunities Tab (discovery engine)                    │
│  │  ├─ AutoApply Tab (automated submissions)                   │
│  │  └─ Intelligence Tab (PIL dossier viewer) [NEW]             │
│  ├─ Knowledge Base                                              │
│  ├─ Application Drafts                                          │
│  └─ Admin Panel                                                 │
│                                                                 │
│  API ROUTES (src/app/api/)                                      │
│  ├─ /api/discovery/* (opportunity import)                      │
│  ├─ /api/autoapply/* (queue population + submission)           │
│  ├─ /api/intelligence/* (PIL queries) [NEW]                    │
│  ├─ /api/cron/* (scheduled jobs)                               │
│  ├─ /api/health (liveness check)                               │
│  ├─ /api/metrics (Prometheus export)                           │
│  └─ /api/auth/* (NextAuth)                                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│           PROSPECT INTELLIGENCE LAYER (PIL) [NEW]               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  AGENT ORCHESTRATOR                                             │
│  ├─ Research Run Manager                                        │
│  │  └─ Manages 9 agent families in cascade                      │
│  │                                                              │
│  ├─ Agent Families (47 total)                                   │
│  │  ├─ SUP (6): Entity verification, legal status              │
│  │  ├─ DIS (8): Discovery, reputation, financials              │
│  │  ├─ INT (10): Mission alignment, fit scoring                │
│  │  ├─ REL (6): Relationship tracking, network                 │
│  │  ├─ QLF (5): Capacity estimation, eligibility               │
│  │  ├─ STR (4): Strategy alignment                             │
│  │  ├─ KNW (4): Knowledge synthesis                            │
│  │  ├─ OPS (1): Operational complexity                         │
│  │  └─ APP (3): Application recommendation                     │
│  │                                                              │
│  └─ Dossier Output                                              │
│     └─ 80+ field comprehensive prospect profile                │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│           DATA LAYER (Supabase PostgreSQL)                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  DISCOVERY SCHEMA                                               │
│  ├─ opportunities (sam.gov, grants.gov, foundation research)   │
│  ├─ prospects (basic lead data)                                │
│  └─ discovered_opportunities (match scoring)                   │
│                                                                 │
│  PIL SCHEMA [NEW]                                               │
│  ├─ pil_prospects (entity metadata)                             │
│  ├─ pil_research_runs (cascade status tracking)                 │
│  ├─ pil_prospect_dossiers (80+ column output per family)       │
│  └─ pil_agent_run_events (audit trail)                          │
│                                                                 │
│  AUTOAPPLY SCHEMA                                               │
│  ├─ autoapply_submission_queue (forms to fill)                 │
│  ├─ pil_application_profiles (BEN-APP-01 output) [NEW]        │
│  ├─ pil_priority_scores (BEN-APP-02 output) [NEW]              │
│  └─ form_responses (submitted applications)                    │
│                                                                 │
│  SALES & ENGAGEMENT SCHEMA                                      │
│  ├─ outreach_campaigns (org-scoped, RLS-protected)             │
│  ├─ campaign_steps (steps in campaign)                          │
│  ├─ contact_lists (recipients)                                  │
│  ├─ engagement_history (opens, clicks)                          │
│  └─ suppression_list (CAN-SPAM compliance, RLS-protected)      │
│                                                                 │
│  AUTH & METADATA                                                │
│  ├─ profiles (user profiles, RLS-isolated)                      │
│  ├─ organizations (tenant data)                                 │
│  ├─ subscriptions (pricing tiers)                               │
│  └─ audit_logs (security + compliance)                          │
│                                                                 │
│  INDEXES: 50+ on hot tables                                     │
│  RLS POLICIES: 40+ (tenant isolation enforced)                  │
│  TOTAL COLUMNS: 400+                                            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│              BACKGROUND WORKER (Railway)                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  DISCOVERY JOBS                                                 │
│  ├─ SAM.gov scraper (daily)                                     │
│  ├─ Grants.gov parser (daily)                                   │
│  └─ Foundation research (weekly)                                │
│                                                                 │
│  PIL JOBS [NEW]                                                 │
│  ├─ Prospect intelligence cascade (on-demand + batch)           │
│  ├─ Dossier updates (incremental)                               │
│  └─ Agent queue processor                                       │
│                                                                 │
│  AUTOAPPLY JOBS                                                 │
│  ├─ Queue population (from dossiers or prospects)               │
│  ├─ Form filling + submission                                   │
│  └─ Result tracking                                             │
│                                                                 │
│  EMAIL JOBS                                                     │
│  ├─ Daily digest (8 AM UTC)                                     │
│  ├─ Follow-up reminders (9 AM MON UTC)                          │
│  └─ Weekly report (10 AM FRI UTC)                               │
│                                                                 │
│  MONITORING                                                     │
│  ├─ Health checks (every 5 min)                                │
│  ├─ Metric exports (Prometheus)                                 │
│  └─ Error logging (structured JSON)                             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│         INTEGRATIONS & EXTERNAL SERVICES                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  GOVERNMENT DATA                                                │
│  ├─ SAM.gov (entity lookup, rate-limited 10/sec)               │
│  ├─ Grants.gov (opportunity XML import)                         │
│  └─ Foundation research (web scraping)                          │
│                                                                 │
│  GEOLOCATION                                                    │
│  ├─ Google Maps API (geocoding)                                 │
│  └─ Google Geocoding API (address validation)                   │
│                                                                 │
│  FEATURE MANAGEMENT                                             │
│  └─ LaunchDarkly (5 flags for PIL rollout)                      │
│                                                                 │
│  MONITORING                                                     │
│  ├─ Prometheus (metrics scraping)                               │
│  ├─ Grafana (dashboards + visualization)                        │
│  ├─ Alertmanager (alert routing to Slack)                       │
│  └─ Supabase (database monitoring)                              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## DATA FLOW: PROSPECT → DOSSIER → APPLICATION

```
1. DISCOVERY PHASE
   ├─ SAM.gov scraper finds entity (daily)
   ├─ Data imported to pil_prospects
   └─ Trigger auto-creates pil_research_run (status: pending)

2. RESEARCH PHASE (Cascade)
   ├─ SUP Family (6 agents)
   │  └─ Output: legal_name, ein, foundation_type, annual_giving
   ├─ DIS Family (8 agents)
   │  └─ Output: reputation_score, financials, web_presence
   ├─ INT Family (10 agents)
   │  └─ Output: cause_alignment, geography_fit, overall_score
   ├─ REL Family (6 agents)
   │  └─ Output: known_connections, relationship_status
   ├─ QLF Family (5 agents)
   │  └─ Output: capacity_estimate, eligibility_status, ask_range
   ├─ STR Family (4 agents)
   │  └─ Output: optimal_contact_time, readiness_score
   ├─ KNW Family (4 agents)
   │  └─ Output: sector_benchmarks, regulatory_environment
   ├─ OPS Family (1 agent)
   │  └─ Output: submission_difficulty, effort_hours
   └─ APP Family (3 agents)
      ├─ APP-01: application_profile (form fit)
      ├─ APP-02: priority_score (recommendation ranking)
      └─ APP-03: submission orchestrator (queue population)

3. DOSSIER OUTPUT
   └─ pil_prospect_dossiers row created with ALL 80+ fields

4. AUTOAPPLY PHASE
   ├─ Queue populated from dossier (higher confidence = earlier)
   ├─ Form filler agent uses dossier context
   ├─ Application submitted
   └─ Result tracked in form_responses

5. ENGAGEMENT TRACKING
   ├─ Campaign created (if approved)
   ├─ Follow-up emails scheduled
   └─ Results tracked in engagement_history
```

---

## SECURITY ARCHITECTURE

### Row-Level Security (RLS)
- **40+ policies** enforced at database level
- **Organization isolation:** SELECT/INSERT/UPDATE/DELETE filtered by org_id
- **No cross-org visibility** (Org A cannot query Org B's data even via API)

### Authentication
- **NextAuth** with passwordless email login
- **Supabase Auth** for database user context
- **JWT tokens** with org_id embedded in claims

### Data Protection
- **Encryption at rest** (Supabase managed)
- **TLS 1.3** for all connections
- **Sensitive data** (API keys, tokens) stored in .env only, never in code
- **Audit logs** for all data mutations

### CAN-SPAM Compliance
- **suppression_list table** RLS-protected per organization
- **Email unsubscribe** automatically added to list
- **Bounce handling** removes invalid addresses

---

## DEPLOYMENT ARCHITECTURE

### Frontend (Vercel)
- **Next.js 15** with App Router
- **SSR** for discovery pages (SEO)
- **CSR** for dashboard (interactive)
- **Auto-deploy** on git push (GitHub → Vercel)
- **Cron routes** (daily digest, reminders, reports)

### Worker (Railway)
- **Node.js 20**
- **Bull queue** for job processing
- **Concurrency:** 5-20 jobs parallel (configurable)
- **Logging:** Structured JSON to Supabase

### Database (Supabase)
- **PostgreSQL 15**
- **Connection pooling** (PgBouncer)
- **PITR** 7-day retention
- **Automated backups** + S3 cross-region replication

---

## MONITORING STACK

### Metrics Collection
- **Prometheus:** 11 metric types (agent runs, API latency, DB queries, auth, dossier completion)
- **prom-client:** In-process metric collection
- **Endpoint:** GET /api/metrics (pulls live counters + histograms)

### Dashboards & Visualization
- **Grafana:** 5 dashboards
  - PIL Agent Health (success rates, duration, errors)
  - API Performance (latency, throughput, errors)
  - Database (slow queries, connection pool, cache hits)
  - System (memory, CPU, errors)
  - AutoApply (queue depth, submission rates, success)

### Alerting
- **Prometheus Alertmanager:** Routes alerts to Slack
- **Thresholds:**
  - Error rate > 5% → CRITICAL (page on-call)
  - Latency p95 > 5s → WARNING
  - Agent family failure > 5% → CRITICAL
  - Auth failures > 0.1/sec → CRITICAL

### Logging
- **Winston:** Structured JSON logging
- **Levels:** debug, info, warn, error, critical
- **Destinations:** Console + Supabase
- **Query:** SELECT * FROM logs WHERE severity='error' AND timestamp > NOW() - INTERVAL '1 hour'

---

## SCALABILITY DESIGN

### Horizontal Scaling
- **Vercel:** Auto-scales frontend (global CDN, 100+ edge regions)
- **Railway:** Scale worker concurrency (5-50 jobs parallel)
- **Supabase:** Connection pooling, read replicas (on Enterprise plan)

### Rate Limiting
- **SAM.gov:** 10 requests/sec (built-in backoff)
- **Agent cascade:** Max 10 concurrent research runs (configurable via feature flag)
- **API:** 100 requests/min per org (token-based)

### Caching
- **Prospect dossiers:** Cached 24h in Redis (read-heavy)
- **Application profiles:** Cached per org session
- **Opportunity data:** Cached 6h (SAM.gov updates daily)

---

## DISASTER RECOVERY

### Data Backup
- **PITR:** 7-day point-in-time recovery (PostgreSQL WAL)
- **S3 Backups:** Daily encrypted SQL dumps, 90-day retention
- **Geo-redundancy:** Cross-region replication (us-east-1 → us-west-2)

### Failover Strategy
- **Circuit breaker:** Agents fail gracefully, return cached data
- **Fallback system:** Revert to legacy prospect system (pil-autoapply-source flag)
- **Health checks:** Every 5 min, /api/health endpoint monitored

### Incident Response
- **On-call rotation:** 24/7 coverage
- **Runbook:** SEV-1/SEV-2/SEV-3 procedures documented
- **Post-mortem:** Within 24h of critical incident

---

## COST OPTIMIZATION

### Compute
- **Vercel:** $0 (free tier + pro overages)
- **Railway:** Worker hourly + job count (est. $200-400/month)

### Database
- **Supabase:** $500/month (prod tier, 20GB storage)
- **Backup S3:** $20/month (100 daily backups, 90-day retention)

### Monitoring
- **Prometheus:** Self-hosted (Railway worker)
- **Grafana:** Self-hosted (Vercel)
- **Total monitoring:** Minimal additional cost

### Total Monthly: ~$800-1000

---

**[END OF ARCHITECTURE_POST_BUILD]**
