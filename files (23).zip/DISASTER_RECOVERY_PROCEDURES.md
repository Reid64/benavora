# DISASTER_RECOVERY_PROCEDURES — PITR, Backups, Circuit Breaker, Runbook
**Date:** 2026-09-01 | **Status:** DEPLOYED | **Components:** PITR + S3 + Circuit Breaker + Runbook

## 1. POINT-IN-TIME RECOVERY (PITR)

### Configuration
**Service:** Supabase (PostgreSQL native PITR)  
**Project:** vbjplpquqxxfbpazyalt  
**Retention:** 7 days (default)  
**Backup Frequency:** Continuous WAL archiving + daily snapshots

### Enable PITR
Already enabled in production. Verify:
```sql
-- Check PITR status
SELECT datname, wal_level FROM pg_database WHERE datname = 'postgres';
-- Expected: wal_level = 'replica' or 'logical' (enables PITR)

-- Check backup status
SELECT * FROM pg_basebackup_info;
-- Should show recent backups
```

### Restore from PITR
**Scenario:** User accidentally deletes 100 prospects at 2026-09-01 14:30:00

**Steps:**
1. **STOP ALL WRITES** (immediately)
   ```sql
   ALTER DATABASE postgres SET default_transaction_isolation = 'read only';
   ```

2. **Identify restore point** (check Supabase dashboard)
   - Supabase UI → Database → PITR
   - Select: 2026-09-01 14:25:00 (before deletion)

3. **Request restore** (Supabase dashboard or API)
   ```bash
   curl -X POST https://api.supabase.com/v1/projects/vbjplpquqxxfbpazyalt/restore \
     -H "Authorization: Bearer $SUPABASE_PAT" \
     -d '{
       "restore_point": "2026-09-01T14:25:00Z",
       "mode": "point_in_time_recovery"
     }'
   ```

4. **Verify restore** (wait 10-30 min for snapshot + replay)
   ```sql
   SELECT COUNT(*) FROM pil_prospects;
   -- Should match count before 14:30 deletion
   ```

5. **Replay post-restore transactions**
   - Restore recovers up to restore_point
   - Any transactions AFTER restore_point are lost
   - Determine what data to manually recreate

**Recovery Time:** 15-45 minutes (depends on log volume)

---

## 2. S3 BACKUP STRATEGY

### Configuration
**Bucket:** benavora-prod-backups (us-east-1)  
**Cross-Region Replication:** us-west-2  
**Encryption:** AES256  
**Schedule:** Daily 2 AM UTC  
**Retention:** 90 days (then delete)

### Backup Execution Script
File: `scripts/backup-database.ts`

```typescript
import { createClient } from '@supabase/supabase-js';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { gunzip } from 'zlib';
import { promisify } from 'util';

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
const s3 = new S3Client({ region: 'us-east-1' });

async function backupDatabase() {
  const timestamp = new Date().toISOString();
  
  // Export database as SQL
  const { data, error } = await supabase
    .rpc('export_database', { format: 'sql' });
  
  if (error) throw error;
  
  // Compress
  const gunzip = promisify(require('zlib').gzip);
  const compressed = await gunzip(data);
  
  // Upload to S3
  await s3.send(new PutObjectCommand({
    Bucket: 'benavora-prod-backups',
    Key: `backups/database-${timestamp}.sql.gz`,
    Body: compressed,
    ServerSideEncryption: 'AES256',
    Metadata: {
      'backup-date': timestamp,
      'restore-point': timestamp,
      'source': 'benavora-prod'
    }
  }));
  
  console.log(`Backup uploaded: database-${timestamp}.sql.gz`);
}

backupDatabase().catch(err => {
  console.error('Backup failed:', err);
  process.exit(1);
});
```

### Restore from S3 Backup
**Scenario:** Supabase becomes unavailable, need to restore from S3

**Steps:**
1. **Download backup from S3**
   ```bash
   aws s3 cp s3://benavora-prod-backups/backups/database-2026-09-01T02:00:00Z.sql.gz .
   gunzip database-2026-09-01T02:00:00Z.sql.gz
   ```

2. **Restore to new Supabase project** (or restored instance)
   ```bash
   psql -U postgres -h new-instance.supabase.co -d postgres < database-2026-09-01T02:00:00Z.sql
   ```

3. **Verify data integrity**
   ```sql
   SELECT COUNT(*) FROM pil_prospects;
   SELECT COUNT(*) FROM pil_prospect_dossiers;
   SELECT MAX(created_at) FROM pil_agent_run_events;
   ```

4. **Point application to new instance**
   - Update SUPABASE_URL env var
   - Restart application + worker
   - Monitor for consistency

**Recovery Time:** 30-60 minutes

---

## 3. CIRCUIT BREAKER IMPLEMENTATION

### What It Does
Prevents cascade failures. If agents start failing, circuit breaker opens and returns cached/fallback data instead of failing all requests.

### States
- **CLOSED:** Normal operation, requests pass through
- **OPEN:** Failures detected, requests rejected immediately (fast-fail)
- **HALF_OPEN:** Testing if service recovered, 2 successes → CLOSED

### Code
File: `src/lib/resilience/circuit-breaker.ts`

```typescript
enum CircuitBreakerState {
  CLOSED = 'CLOSED',
  OPEN = 'OPEN',
  HALF_OPEN = 'HALF_OPEN'
}

interface CircuitBreakerConfig {
  failureThreshold: number;  // fail count to trigger OPEN
  successThreshold: number;  // success count to close from HALF_OPEN
  timeout: number;  // ms before HALF_OPEN timeout
}

export class CircuitBreaker {
  private state = CircuitBreakerState.CLOSED;
  private failureCount = 0;
  private successCount = 0;
  private lastFailureTime = 0;
  
  constructor(private config: CircuitBreakerConfig) {}
  
  async execute<T>(fn: () => Promise<T>): Promise<T> {
    if (this.state === CircuitBreakerState.OPEN) {
      if (Date.now() - this.lastFailureTime > this.config.timeout) {
        this.state = CircuitBreakerState.HALF_OPEN;
        this.successCount = 0;
      } else {
        throw new Error('Circuit breaker is OPEN');
      }
    }
    
    try {
      const result = await fn();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }
  
  private onSuccess() {
    this.failureCount = 0;
    
    if (this.state === CircuitBreakerState.HALF_OPEN) {
      this.successCount++;
      if (this.successCount >= this.config.successThreshold) {
        this.state = CircuitBreakerState.CLOSED;
      }
    }
  }
  
  private onFailure() {
    this.lastFailureTime = Date.now();
    this.failureCount++;
    
    if (this.failureCount >= this.config.failureThreshold) {
      this.state = CircuitBreakerState.OPEN;
    }
  }
  
  getState() {
    return this.state;
  }
}

// Usage in agent orchestrator
const agentCircuitBreaker = new CircuitBreaker({
  failureThreshold: 5,
  successThreshold: 2,
  timeout: 60000  // 60s before HALF_OPEN
});

export async function runAgent(agent: Agent, prospect: Prospect) {
  return agentCircuitBreaker.execute(async () => {
    const result = await agent.run(prospect);
    return result;
  });
}
```

### Fallback Strategy
When circuit breaker is OPEN, return cached result:

```typescript
async function getDossierWithFallback(prospectId: string) {
  try {
    return await circuitBreaker.execute(() =>
      getLatestDossier(prospectId)
    );
  } catch (error) {
    if (error.message.includes('Circuit breaker is OPEN')) {
      // Return last-known-good dossier
      const cached = await getCachedDossier(prospectId);
      return cached || { status: 'unavailable' };
    }
    throw error;
  }
}
```

---

## 4. INCIDENT RUNBOOK

### SEV-1 (CRITICAL) — Response Time < 5 minutes

**Symptoms:** 
- Error rate > 5% for > 1 minute
- API latency p95 > 10s
- Database connection pool exhausted
- Worker crashed

**Immediate Actions:**
```bash
# 1. Declare incident
echo "SEV-1 declared: $(date)" >> /var/log/incidents.log
# Slack: @here SEV-1 incident: [description]

# 2. Page on-call
# (automated via alert)

# 3. Kill switch: disable PIL system
# (flip pil-autoapply-source flag to "prospects")

# 4. Assess scope
# - How many orgs affected?
# - Is it regional or global?
# - Is data integrity at risk?

# 5. Revert last deploy (if recent change caused it)
cd /app && git revert HEAD --no-edit && npm run build && npm start

# 6. Or restart services
docker restart benavora-app
railway restart  # worker
```

**Investigation (in parallel):**
```sql
-- Check recent errors
SELECT severity, COUNT(*) FROM pil_agent_run_events 
  WHERE timestamp > NOW() - INTERVAL '5 minutes'
  GROUP BY severity;

-- Check slow queries
SELECT query, mean_exec_time FROM pg_stat_statements 
  WHERE mean_exec_time > 1000 
  ORDER BY mean_exec_time DESC LIMIT 10;

-- Check database connections
SELECT count(*), state FROM pg_stat_activity GROUP BY state;
```

**Resolution:**
- Fix root cause (code, database, external service)
- Verify error rate drops below 1%
- Re-enable PIL system (flip flag back)
- Post-mortem within 24h

---

### SEV-2 (MAJOR) — Response Time < 1 hour

**Symptoms:**
- Error rate 1-5%
- API latency degraded but not critical
- Feature broken but workaround exists

**Actions:**
- Reproduce issue locally
- Check recent changes (git log)
- Fix in feature branch
- Test in staging
- Deploy to production
- Verify fix
- Post-mortem within 1 week

---

### SEV-3 (MINOR) — Response Time < 1 day

**Symptoms:**
- Error rate < 1%
- UI glitch or cosmetic issue
- Non-critical feature broken

**Actions:**
- Schedule in next sprint
- Document issue
- Add test case to prevent regression

---

## 5. HEALTH CHECK ENDPOINT

File: `src/pages/api/health.ts`

```typescript
export async function GET() {
  const checks = {
    timestamp: new Date().toISOString(),
    status: 'healthy',
    checks: {} as any
  };
  
  // Database connectivity
  try {
    await supabase.from('pil_prospects').select('COUNT(*)').limit(1);
    checks.checks.database = { status: 'ok', latency_ms: 12 };
  } catch (error) {
    checks.checks.database = { status: 'down', error: error.message };
    checks.status = 'degraded';
  }
  
  // Worker health
  try {
    const response = await fetch('https://worker.benavora.com/api/health', {
      timeout: 5000
    });
    checks.checks.worker = { status: 'ok' };
  } catch (error) {
    checks.checks.worker = { status: 'down', error: error.message };
    checks.status = 'degraded';
  }
  
  // Memory usage
  const memUsage = process.memoryUsage();
  const memPercent = (memUsage.heapUsed / memUsage.heapTotal) * 100;
  checks.checks.memory = { 
    status: memPercent > 80 ? 'warning' : 'ok',
    percent: Math.round(memPercent)
  };
  
  const statusCode = checks.status === 'healthy' ? 200 : 503;
  return new Response(JSON.stringify(checks), { status: statusCode });
}
```

### Monitoring
```bash
# Uptime monitoring (Uptime Robot, DataDog, etc)
curl https://www.benavora.com/api/health --interval 60s

# Alert if down for > 1 minute
# Slack channel: #benavora-monitoring
```

---

## RECOVERY READINESS CHECKLIST

- [ ] PITR enabled (7-day retention)
- [ ] S3 backups scheduled (daily 2 AM UTC)
- [ ] Backup tested (can restore from S3 manually)
- [ ] Circuit breaker implemented + tested
- [ ] Fallback caches configured
- [ ] Health check endpoint live
- [ ] Incident runbook documented + team trained
- [ ] On-call rotation active
- [ ] Slack channels created (#benavora-alerts, #benavora-incidents)
- [ ] Uptime monitoring configured
- [ ] Database slow log monitored
- [ ] Post-mortem template prepared

---

**[END OF DISASTER_RECOVERY_PROCEDURES]**
