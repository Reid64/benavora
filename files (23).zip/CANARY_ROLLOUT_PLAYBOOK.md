# CANARY_ROLLOUT_PLAYBOOK — Week-by-Week Procedures, Checklists, Decision Points
**Date:** 2026-09-01 | **Status:** READY | **Duration:** 7 weeks | **Target:** 100% rollout

## WEEK 1-2: CANARY 10% (5 Beta Orgs)

### PRE-LAUNCH CHECKLIST (Day 0)

**Morning (9 AM):**
- [ ] All 5 beta orgs confirmed ready (have active users + 50+ prospects)
- [ ] Support team briefed on new features (Intelligence tab, dossier queries)
- [ ] Slack channels created: #benavora-alerts, #benavora-canary, #org-pil-testing-{1..5}
- [ ] LaunchDarkly flags configured (pil-enabled=true for 5 orgs)
- [ ] Prometheus scraping /api/metrics (verify data flowing)
- [ ] Grafana dashboards live + showing data
- [ ] E2E tests passing locally (pnpm exec playwright test)
- [ ] SAM.gov scale test passed (100 concurrent IDs, 0 errors)
- [ ] Dossier completion baseline measured (p50/p95/p99)
- [ ] Health check responding (curl /api/health → 200 OK)

**Afternoon (2 PM):**
- [ ] Send email to 5 beta orgs: "Pilot launches tomorrow, Intelligence tab available"
- [ ] Schedule daily standup call: 9 AM each day for next 7 days
- [ ] Verify on-call engineer assigned for week 1-2
- [ ] Document baseline metrics (error rate, latency, completion time)

**Evening (5 PM):**
- [ ] Final verification: all systems green
- [ ] Go/No-Go decision: Reid approves or delays

---

### CANARY DAYS 1-7 (Week 1-2)

**DAILY STANDUP: 9 AM** (Reid + Claude + on-call + support)

**Agenda (15 min):**
```
Question 1: Error Rate?
  Alert threshold: > 5% triggers rollback
  Target: < 0.5%
  Check: SELECT rate(benavora_agent_events_logged_total{severity="error"}[5m]) / rate(benavora_agent_events_logged_total[5m])
  
Question 2: Dossier Completion?
  Target: > 90%
  Check: SELECT COUNT(*) WHERE dossier_complete=true / COUNT(*)
  
Question 3: API Latency?
  Target p95: < 2 seconds
  Check: Grafana dashboard "API Latency p95"
  
Question 4: SAM.gov Integration?
  Target: < 1% error rate
  Check: integration_parser_errors table
  
Question 5: Data Integrity?
  Check: 5 random dossiers, verify all 80+ fields populated
  Check: Org A cannot query Org B data (RLS working)
  
Question 6: User Feedback?
  Check: Slack channels #org-pil-testing-{1..5}
  Any issues reported?
  Any feature requests?
  Satisfaction?
```

**Decision Matrix:**
| Metric | Green | Yellow | Red (Rollback) |
|--------|-------|--------|---|
| Error Rate | < 0.5% | 0.5-5% | > 5% |
| Completion | > 90% | 80-90% | < 80% |
| Latency p95 | < 2s | 2-5s | > 5s |
| SAM.gov errors | < 1% | 1-2% | > 2% |
| RLS violations | 0 | 0 | 1+ |

**If ALL Green:** Continue to day 2  
**If ANY Yellow:** Investigate, no rollback yet  
**If ANY Red:** IMMEDIATE ROLLBACK (see procedure below)

---

### ROLLBACK PROCEDURE (If triggered)

```powershell
# STEP 1: Immediate (< 2 min)
# Disable PIL AutoApply (revert to old system)
$ld_patch = @{
  fallthrough = @{
    variation = 0  # "prospects" (safe default)
  }
}

# Via LaunchDarkly API or UI
# Result: All orgs fall back instantly

# STEP 2: Notify (< 5 min)
# Slack @channel: "PIL rollout paused due to [error type]. Reverted to legacy system."

# STEP 3: Investigate (ongoing)
# Check logs, reproduce error, find root cause
# Debug in staging

# STEP 4: Fix & Test (1-4 hours)
# Deploy fix to staging
# Re-run same tests that failed
# Get approval from Reid

# STEP 5: Restart Canary (if fix found)
# Re-enable flag for same 5 orgs
# Monitor for 24h before proceeding

# OR Delay Canary (if no fix)
# Schedule for next week
# Document lessons learned
```

---

### EXIT CRITERIA: CANARY SUCCESS

**Must have 7 consecutive DAYS with:**
- ✅ Error rate < 0.5% (all 7 days)
- ✅ Dossier completion > 90% (all 7 days)
- ✅ API latency p95 < 2s (all 7 days)
- ✅ SAM.gov errors < 1% (all 7 days)
- ✅ Zero RLS violations (all 7 days)
- ✅ Zero data loss incidents (all 7 days)
- ✅ Support team zero escalations
- ✅ All 5 beta orgs feedback positive (manual survey)

**If YES to all:** Proceed to Week 3 expansion  
**If NO:** Investigate failures, fix, re-run 7-day canary

---

## WEEK 3-4: CANARY 25% (15 Beta Orgs)

### PRE-EXPANSION CHECKLIST (Day 15)

**Analysis of Week 1-2:**
- [ ] Compile metrics report (error rates, latency, completion, feedback)
- [ ] Document any incidents + root causes + fixes
- [ ] Post-mortem if any issues occurred
- [ ] Reid approval to expand
- [ ] Select 10 additional beta orgs (new cohort)

**Expansion Setup:**
- [ ] Add 10 new org IDs to LaunchDarkly targeting (now 15 total)
- [ ] Notify 10 new orgs (email + support briefing)
- [ ] Create Slack channels for 10 new orgs
- [ ] Verify all 15 orgs have 50+ prospects

**Monitoring:**
- [ ] Same daily standup (9 AM, 15 min)
- [ ] Same metrics targets
- [ ] Same rollback procedure if needed

---

### EXIT CRITERIA: CANARY 25% SUCCESS

**Same as 10%, but for 15 orgs:**
- ✅ 7 consecutive days all green
- ✅ Error rate < 0.5%
- ✅ Dossier completion > 90%
- ✅ All 15 orgs positive feedback

**If YES:** Proceed to Week 5 GA (50%)  
**If NO:** Fix issues, extend canary

---

## WEEK 5-6: GENERAL AVAILABILITY 50% (500+ Orgs)

### PRE-GA CHECKLIST (Day 29)

**Major Expansion:**
- [ ] Update pil-enabled flag to 50% of all orgs
- [ ] Support team fully briefed + trained
- [ ] On-call rotation active (24/7)
- [ ] Incident runbook accessible
- [ ] Grafana + monitoring dashboard active
- [ ] Alert thresholds set in Prometheus
- [ ] Slack #benavora-incidents active + monitored

**Communication:**
- [ ] Send email to 500 orgs: "Intelligence feature now available"
- [ ] Update help docs + training materials
- [ ] Schedule optional live webinar for orgs

**Monitoring Escalation:**
- [ ] Someone monitoring metrics 24/7 (shifts)
- [ ] Alerts go to #benavora-alerts (paged if critical)
- [ ] SLA: < 15 min response to error rate spike

---

### DAILY MONITORING (Week 5-6)

**Instead of 9 AM standup, continuous monitoring:**
- Grafana dashboard always visible (on team display)
- Automated alerts to Slack (errors, latency spikes)
- Manual spot-checks: 3 random orgs daily, verify dossiers
- Weekly metrics review (every Friday 10 AM)

**Exit Criteria:**
- ✅ 14 consecutive days (2 weeks) all green
- ✅ < 0.1% error rate (higher bar for GA)
- ✅ Dossier completion > 95%
- ✅ Customer satisfaction > 4.5/5 (survey)

**If YES:** Proceed to Week 7 (100%)  
**If NO:** Pause expansion, investigate

---

## WEEK 7+: FULL ROLLOUT 100%

### GA LAUNCH (Day 43)

**Final Expansion:**
- [ ] Set pil-enabled = true for 100% of orgs
- [ ] Send system-wide announcement: "Intelligence feature now generally available"
- [ ] Deprecate old prospect system (no longer used)
- [ ] Archive old pil_prospects data to S3

**Monitoring:**
- Continue 24/7 monitoring
- On-call rotation continues
- Weekly metrics review

**Cleanup:**
- [ ] Archive old code (but keep in git history)
- [ ] Delete old prospect-related routes (if no longer needed)
- [ ] Update docs to reference PIL only

---

## DECISION FLOWCHART

```
START: Week 1 Canary (10%)
  ↓
[Monitor 7 days]
  ↓
Success? 
  ├─ NO → Investigate + Fix → Retry Canary
  └─ YES ↓
Week 3 Canary (25%)
  ↓
[Monitor 7 days]
  ↓
Success?
  ├─ NO → Investigate + Fix → Retry Canary
  └─ YES ↓
Week 5 GA (50%)
  ↓
[Monitor 14 days]
  ↓
Success?
  ├─ NO → Investigate + Fix → Retry GA
  └─ YES ↓
Week 7 Full Rollout (100%)
  ↓
[Monitor forever]
  ↓
END: All orgs on PIL
```

---

## DAILY REPORT TEMPLATE

```
CANARY DAY 3 REPORT
Date: 2026-09-03
Cohort: 5 beta orgs

METRICS:
✅ Error Rate: 0.2% (target < 0.5%)
✅ Completion: 94% (target > 90%)
✅ Latency p95: 1.8s (target < 2s)
✅ SAM.gov: 0.7% errors (target < 1%)
✅ RLS: No violations

INCIDENTS: None

USER FEEDBACK:
- Org A: "Great! Seeing better recommendations"
- Org B: "Feature works, a bit slow sometimes"
- Org C-E: No feedback yet

ACTIONS TODAY:
- Monitored dossier queue (5 prospects, all completed)
- Verified 5 random dossiers (all fields populated)
- RLS spot-check: Org A cannot query Org B data ✓

NEXT 24H:
- Continue monitoring
- No changes planned
- Next standup: 2026-09-04 09:00

STATUS: 🟢 ALL GREEN
```

---

**[END OF CANARY_ROLLOUT_PLAYBOOK]**
