# FEATURE_FLAG_DEFINITIONS — All 5 LaunchDarkly Flags for PIL Rollout
**Date:** 2026-09-01 | **Status:** READY FOR CONFIGURATION | **Flags:** 5 | **SDK:** LaunchDarkly

## FLAG 1: pil-enabled

**Purpose:** Master on/off switch for entire PIL system  
**Type:** Boolean  
**Default:** false (safe, old system active)  
**Priority:** CRITICAL (if off, reverts to old prospect-based system)

### Configuration
```json
{
  "key": "pil-enabled",
  "name": "PIL System Enabled",
  "description": "Enable Prospect Intelligence Layer for organization",
  "kind": "boolean",
  "on": true,
  "fallthrough": {
    "variation": 0  // false
  },
  "offVariation": 1,  // true
  "variations": [
    { "value": false, "name": "Disabled" },
    { "value": true, "name": "Enabled" }
  ],
  "targets": {
    "users": [],
    "organizations": []  // will populate with beta org IDs
  },
  "rules": [
    {
      "variation": 1,  // enabled
      "trackEvents": true,
      "conditions": [
        {
          "attribute": "organization_id",
          "op": "in",
          "values": [
            "org_beta_001", "org_beta_002", "org_beta_003", "org_beta_004", "org_beta_005"
          ]
        }
      ]
    }
  ]
}
```

### Usage in Code
```typescript
// File: src/app/(dashboard)/layout.tsx
const pilEnabled = await ld.isFeatureEnabled('pil-enabled', user, false);

if (pilEnabled) {
  // Show Intelligence tab
  return <IntelligenceDashboardTab />;
} else {
  // Hide tab
  return null;
}
```

### Rollout Schedule
```
Week 1-2: Canary 10% (5 beta orgs)
Week 3-4: Expand 25% (15 beta orgs + original 5)
Week 5-6: General 50% (500+ orgs)
Week 7+:  Full 100% (all orgs)
```

---

## FLAG 2: pil-dossier-ui

**Purpose:** Show/hide Intelligence tab in dashboard  
**Type:** Boolean  
**Default:** false (tab hidden)  
**Dependency:** pil-enabled must be true first

### Configuration
```json
{
  "key": "pil-dossier-ui",
  "name": "PIL Dossier Dashboard UI",
  "description": "Show Prospect Intelligence dashboard tab",
  "kind": "boolean",
  "on": true,
  "fallthrough": { "variation": 0 },  // false
  "rules": [
    {
      "variation": 1,  // show tab
      "conditions": [
        { "attribute": "pil-enabled", "op": "equals", "value": true }
      ]
    }
  ]
}
```

### Usage
```typescript
// File: src/app/(dashboard)/dashboard-navigation.tsx
const pilDossierUI = await ld.isFeatureEnabled('pil-dossier-ui', user, false);

return (
  <nav>
    <Tab href="/dashboard/opportunities">Opportunities</Tab>
    <Tab href="/dashboard/autoapply">AutoApply</Tab>
    {pilDossierUI && (
      <Tab href="/dashboard/intelligence">
        Intelligence <span className="badge">Beta</span>
      </Tab>
    )}
  </nav>
);
```

---

## FLAG 3: pil-autoapply-source

**Purpose:** Switch AutoApply data source (prospects vs dossiers)  
**Type:** String (enum)  
**Default:** "prospects" (safe fallback to old system)  
**Critical:** If dossiers fails, flip to "prospects" immediately

### Configuration
```json
{
  "key": "pil-autoapply-source",
  "name": "AutoApply Data Source",
  "description": "Pull queue population from 'prospects' (legacy) or 'dossiers' (PIL)",
  "kind": "string",
  "on": true,
  "fallthrough": { "variation": 0 },  // "prospects"
  "variations": [
    { "value": "prospects", "name": "Legacy Prospects" },
    { "value": "dossiers", "name": "PIL Dossiers (Intelligent)" }
  ],
  "rules": [
    {
      "variation": 1,  // dossiers
      "conditions": [
        { "attribute": "organization_id", "op": "in", "values": ["org_beta_001", ...] }
      ]
    }
  ]
}
```

### Usage
```typescript
// File: src/lib/autoapply/queue-populator.ts
const source = await ld.getFeatureVariant('pil-autoapply-source', user, 'prospects');

if (source === 'dossiers') {
  return populateFromDossiers(tenantId);
} else {
  return populateFromProspects(tenantId);  // fallback
}
```

### Critical Rollback Path
```powershell
# If error rate spikes > 5%, immediately flip flag
# Via LaunchDarkly UI or API:
curl -X PATCH https://app.launchdarkly.com/api/v2/flags/default/pil-autoapply-source \
  -H "Authorization: Bearer $LD_API_KEY" \
  -d '{
    "fallthrough": { "variation": 0 }  // "prospects"
  }'

# Result: All orgs fall back to old system within seconds
```

---

## FLAG 4: pil-agent-family-strictness

**Purpose:** Control error tolerance in agent cascade  
**Type:** String (enum)  
**Default:** "lenient" (skip individual errors, continue cascade)  
**Values:**
- `lenient`: Skip failing agents, continue to next family
- `strict`: Stop cascade on any agent failure
- `manual_review`: Stop and escalate for manual review

### Configuration
```json
{
  "key": "pil-agent-family-strictness",
  "name": "PIL Agent Error Handling",
  "description": "How to handle agent failures in cascade",
  "kind": "string",
  "on": true,
  "fallthrough": { "variation": 0 },  // "lenient"
  "variations": [
    { "value": "lenient", "name": "Lenient (skip errors)" },
    { "value": "strict", "name": "Strict (stop on error)" },
    { "value": "manual_review", "name": "Manual Review (escalate)" }
  ],
  "rules": [
    {
      "variation": 0,  // lenient
      "conditions": [
        { "attribute": "environment", "op": "equals", "value": "production" }
      ]
    },
    {
      "variation": 1,  // strict
      "conditions": [
        { "attribute": "environment", "op": "equals", "value": "staging" }
      ]
    }
  ]
}
```

### Usage
```typescript
// File: src/lib/pil/research-orchestrator.ts
const strictness = await ld.getFeatureVariant('pil-agent-family-strictness', org, 'lenient');

try {
  await supFamily.run();
  await disFamily.run();
  await intFamily.run();
} catch (error) {
  if (strictness === 'strict') {
    throw error;  // stop cascade
  } else if (strictness === 'manual_review') {
    logEscalation(prospectId, error);
    return null;  // escalate for human review
  } else {  // lenient
    logger.warn(`Agent error, continuing: ${error.message}`);
    // continue to next family
  }
}
```

---

## FLAG 5: pil-max-concurrent-runs

**Purpose:** Limit concurrent agent executions (prevent overload)  
**Type:** Integer  
**Default:** 5 (conservative)  
**Range:** 1-50 (adjust based on worker capacity)

### Configuration
```json
{
  "key": "pil-max-concurrent-runs",
  "name": "Max Concurrent PIL Runs",
  "description": "Maximum number of simultaneous research runs",
  "kind": "number",
  "on": true,
  "fallthrough": { "variation": 0 },  // 5
  "variations": [
    { "value": 5, "name": "Conservative (5)" },
    { "value": 10, "name": "Moderate (10)" },
    { "value": 20, "name": "Aggressive (20)" }
  ],
  "rules": [
    {
      "variation": 0,  // 5 (default, safe)
      "conditions": []
    }
  ]
}
```

### Usage
```typescript
// File: src/lib/pil/queue-manager.ts
const maxConcurrent = await ld.getFeatureVariant('pil-max-concurrent-runs', org, 5);

const activeRuns = await getActiveRunsCount(org.id);
if (activeRuns >= maxConcurrent) {
  // Queue prospect for later
  await queueProspectForLater(prospect);
} else {
  // Start research run now
  await startResearchRun(prospect);
}
```

---

## ROLLOUT DECISION MATRIX

### Week 1-2 Canary: 10% (5 Beta Orgs)

| Flag | Setting | Reason |
|------|---------|--------|
| pil-enabled | true (for 5 beta orgs) | Activate for beta cohort |
| pil-dossier-ui | true (for 5 beta orgs) | Show Intelligence tab |
| pil-autoapply-source | "dossiers" (for 5 beta orgs) | Use new system |
| pil-agent-family-strictness | "lenient" | Skip errors, continue |
| pil-max-concurrent-runs | 5 | Conservative, watch capacity |

**Monitoring:**
- Error rate < 0.5% daily
- Dossier completion > 90%
- User feedback positive
- No data loss incidents

**Exit Criteria:**
- 7 consecutive days all green
- Support team 0 escalations
- Beta orgs confirm working

---

### Week 3-4 Canary: 25% (15 Orgs)

| Flag | Setting | Change |
|------|---------|--------|
| pil-enabled | true (for 20 orgs) | Expand to 20 orgs total |
| pil-dossier-ui | true (for 20 orgs) | Expanded cohort |
| pil-autoapply-source | "dossiers" (20 orgs) | Maintain |
| pil-max-concurrent-runs | 8 | Slightly increase |

**Monitoring:** Same metrics, watch for capacity limits

---

### Week 5-6: 50% (500+ Orgs)

| Flag | Setting | Change |
|------|---------|--------|
| pil-enabled | true (for 500 orgs) | Major expansion |
| pil-autoapply-source | "dossiers" (500 orgs) | Approaching majority |
| pil-max-concurrent-runs | 10 | Scale for volume |

**Critical:** Full monitoring active, on-call ready

---

### Week 7+: 100% GA

| Flag | Setting | Change |
|------|---------|--------|
| pil-enabled | true (all orgs) | Full rollout |
| pil-dossier-ui | true (all orgs) | Standard feature |
| pil-autoapply-source | "dossiers" (all orgs) | New default |
| pil-max-concurrent-runs | 15+ | Scale as needed |

**Action:** Deprecate old prospect system, archive data

---

## ROLLBACK PROCEDURE

**Trigger:** If error rate > 5% or latency p95 > 5s for > 15 minutes

```powershell
# Step 1: Disable PIL system (immediate effect)
curl -X PATCH https://app.launchdarkly.com/api/v2/flags/default/pil-autoapply-source \
  -H "Authorization: Bearer $LD_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "fallthrough": { "variation": 0 }  # "prospects" (safe default)
  }'

# Step 2: Notify team
# Slack message to #benavora-alerts: "PIL rollout paused: error rate spike. Reverted to legacy system."

# Step 3: Investigate
# Review logs, find root cause, determine if revert permanent or temporary

# Step 4: Fix & retry
# Once fixed, re-enable flag for canary cohort only
```

---

## CONFIGURATION IN LaunchDarkly UI

1. Log into LaunchDarkly dashboard
2. Create project "Benavora"
3. For each flag:
   - Click "Create Flag"
   - Fill in name, key, description
   - Set variations (boolean or string)
   - Save
4. For each flag targeting rule:
   - Click "Edit Targeting"
   - Add segment: "benavora_beta_testers" (specify org IDs)
   - Set variation for segment (e.g., true for pil-enabled)
5. Save + publish

---

**[END OF FEATURE_FLAG_DEFINITIONS]**
