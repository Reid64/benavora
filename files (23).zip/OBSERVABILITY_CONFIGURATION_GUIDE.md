# OBSERVABILITY_CONFIGURATION_GUIDE — Prometheus, Grafana, Alerts Setup
**Date:** 2026-09-01 | **Status:** READY FOR DEPLOYMENT | **Components:** Prometheus + Grafana + Alerts + Logging

## PART 1: PROMETHEUS METRICS EXPORT

### Endpoint: GET /api/metrics
**Location:** `src/pages/api/metrics.ts`  
**Content-Type:** `application/vnd.google.protobuf; proto=io.prometheus.client.MetricFamily`  
**Response Format:** Prometheus text format (plaintext with TYPE/HELP comments)

### Metrics Exported (11 types)

#### User Action Metrics
```prometheus
# TYPE benavora_application_submitted_total counter
# HELP benavora_application_submitted_total Total applications submitted
benavora_application_submitted_total{funder_category="housing",request_type="grant",success="true"} 427
benavora_application_submitted_total{funder_category="education",request_type="grant",success="true"} 312
benavora_application_submitted_total{funder_category="health",request_type="grant",success="false"} 15

# TYPE benavora_draft_created_total counter
# HELP benavora_draft_created_total Total drafts created
benavora_draft_created_total{draft_type="grant_application"} 1250
benavora_draft_created_total{draft_type="research_memo"} 320

# TYPE benavora_opportunity_discovered_total counter
# HELP benavora_opportunity_discovered_total Total opportunities discovered
benavora_opportunity_discovered_total{source_system="sam.gov",category="housing"} 2150
benavora_opportunity_discovered_total{source_system="grants.gov",category="education"} 980
```

#### Agent Operation Metrics
```prometheus
# TYPE benavora_agent_run_duration_seconds histogram
# HELP benavora_agent_run_duration_seconds Agent execution duration
benavora_agent_run_duration_seconds_bucket{agent_id="BEN-SUP-01",family="SUP",status="success",le="1"} 245
benavora_agent_run_duration_seconds_bucket{agent_id="BEN-SUP-01",family="SUP",status="success",le="5"} 1024
benavora_agent_run_duration_seconds_bucket{agent_id="BEN-SUP-01",family="SUP",status="success",le="60"} 4521
benavora_agent_run_duration_seconds_bucket{agent_id="BEN-DIS-02",family="DIS",status="success",le="60"} 2018
benavora_agent_run_duration_seconds_bucket{le="+Inf"} 8234
benavora_agent_run_duration_seconds_sum{agent_id="BEN-SUP-01",family="SUP",status="success"} 23421.5
benavora_agent_run_duration_seconds_count{agent_id="BEN-SUP-01",family="SUP",status="success"} 4521

# TYPE benavora_agent_events_logged_total counter
# HELP benavora_agent_events_logged_total Total agent events logged
benavora_agent_events_logged_total{agent_id="BEN-APP-01",event_type="started",severity="info"} 312
benavora_agent_events_logged_total{agent_id="BEN-APP-01",event_type="completed",severity="info"} 310
benavora_agent_events_logged_total{agent_id="BEN-APP-01",event_type="failed",severity="error"} 2

# TYPE benavora_prospect_intelligence_complete_total counter
# HELP benavora_prospect_intelligence_complete_total Total dossiers completed
benavora_prospect_intelligence_complete_total{fit_level="excellent"} 245
benavora_prospect_intelligence_complete_total{fit_level="good"} 812
benavora_prospect_intelligence_complete_total{fit_level="moderate"} 1423
benavora_prospect_intelligence_complete_total{fit_level="low"} 156
```

#### System Health Metrics
```prometheus
# TYPE benavora_api_latency_ms histogram
# HELP benavora_api_latency_ms API request latency
benavora_api_latency_ms_bucket{endpoint="/api/discovery/search",method="GET",status="200",le="100"} 1240
benavora_api_latency_ms_bucket{endpoint="/api/discovery/search",method="GET",status="200",le="1000"} 4521
benavora_api_latency_ms_bucket{endpoint="/api/discovery/search",method="GET",status="200",le="5000"} 4523
benavora_api_latency_ms_sum{endpoint="/api/discovery/search",method="GET",status="200"} 1234567
benavora_api_latency_ms_count{endpoint="/api/discovery/search",method="GET",status="200"} 4523

# TYPE benavora_supabase_query_duration_ms histogram
# HELP benavora_supabase_query_duration_ms Database query duration
benavora_supabase_query_duration_ms_bucket{table="pil_prospect_dossiers",operation="SELECT",le="5"} 856
benavora_supabase_query_duration_ms_bucket{table="pil_prospect_dossiers",operation="SELECT",le="1000"} 2310
benavora_supabase_query_duration_ms_sum{table="pil_prospect_dossiers",operation="SELECT"} 1234567
benavora_supabase_query_duration_ms_count{table="pil_prospect_dossiers",operation="SELECT"} 2310

# TYPE benavora_auth_failures_total counter
# HELP benavora_auth_failures_total Authentication failures
benavora_auth_failures_total{reason="invalid_credentials"} 23
benavora_auth_failures_total{reason="expired_token"} 5
benavora_auth_failures_total{reason="insufficient_permissions"} 2

# TYPE benavora_active_organizations gauge
# HELP benavora_active_organizations Number of active organizations
benavora_active_organizations 547

# TYPE benavora_subscription_revenue_usd gauge
# HELP benavora_subscription_revenue_usd Monthly subscription revenue
benavora_subscription_revenue_usd 180250.00
```

### Implementation
File: `src/pages/api/metrics.ts`
```typescript
import { NextResponse } from 'next/server';
import { metricsRegistry } from '@/lib/observability/metrics';

export async function GET() {
  const metrics = await metricsRegistry.metrics();
  return new NextResponse(metrics, {
    headers: {
      'Content-Type': 'application/vnd.google.protobuf; proto=io.prometheus.client.MetricFamily',
    },
  });
}
```

---

## PART 2: PROMETHEUS CONFIGURATION

### Installation
```bash
cd /opt/prometheus
docker run -d \
  --name prometheus \
  -p 9090:9090 \
  -v /opt/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml \
  -v /opt/prometheus/rules:/etc/prometheus/rules \
  prom/prometheus:latest
```

### prometheus.yml
```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s
  external_labels:
    monitor: 'benavora-prod'

scrape_configs:
  - job_name: 'benavora'
    static_configs:
      - targets: ['https://www.benavora.com/api/metrics']
    scrape_interval: 15s
    scrape_timeout: 10s
    metrics_path: '/api/metrics'
    scheme: 'https'
    
  - job_name: 'benavora-worker'
    static_configs:
      - targets: ['https://worker.benavora.com/api/metrics']
    scrape_interval: 30s
```

### prometheus.rules.yaml
**Location:** `/etc/prometheus/rules/benavora.rules.yaml`

```yaml
groups:
  - name: benavora_alerts
    interval: 30s
    rules:
      # Agent failure rate alert
      - alert: AgentFamilyFailureRate
        expr: |
          (
            rate(benavora_agent_events_logged_total{severity="error"}[5m]) /
            rate(benavora_agent_events_logged_total[5m])
          ) > 0.05
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "Agent failure rate exceeding 5%"
          description: "{{ $labels.family }} family has {{ $value | humanizePercentage }} error rate"

      # API latency alert
      - alert: HighAPILatency
        expr: histogram_quantile(0.95, rate(benavora_api_latency_ms_bucket[5m])) > 5000
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: "API latency p95 exceeding 5s"

      # Auth failure spike
      - alert: AuthFailureSpike
        expr: rate(benavora_auth_failures_total[5m]) > 0.1
        for: 2m
        labels:
          severity: critical
        annotations:
          summary: "Auth failures spiking (> 0.1 failures/sec)"

      # Database performance
      - alert: SupabaseSlowQueries
        expr: histogram_quantile(0.95, rate(benavora_supabase_query_duration_ms_bucket[5m])) > 1000
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "Database queries slow (p95 > 1s)"
```

---

## PART 3: GRAFANA CONFIGURATION

### Dashboard Specification

**Dashboard Name:** Benavora PIL Agents  
**Refresh:** 10 seconds (or manual)  
**Time Range:** Last 24 hours (or user-selected)

#### Panel 1: Agent Success Rate by Family
```json
{
  "title": "Agent Success Rate by Family",
  "targets": [
    {
      "expr": "sum(rate(benavora_agent_events_logged_total{event_type='completed',severity='info'}[5m])) by (family) / sum(rate(benavora_agent_events_logged_total[5m])) by (family)",
      "legendFormat": "{{ family }}"
    }
  ],
  "type": "graph",
  "yaxis": { "format": "percentunit", "min": 0, "max": 1 }
}
```

#### Panel 2: Agent Duration by Family (Histogram)
```json
{
  "title": "Agent Execution Time by Family",
  "targets": [
    {
      "expr": "histogram_quantile(0.95, rate(benavora_agent_run_duration_seconds_bucket[5m])) by (family)",
      "legendFormat": "{{ family }} (p95)"
    }
  ],
  "type": "graph",
  "yaxis": { "format": "s" }
}
```

#### Panel 3: Dossier Completion Rate
```json
{
  "title": "Dossier Completion Rate (per hour)",
  "targets": [
    {
      "expr": "increase(benavora_prospect_intelligence_complete_total[1h])",
      "legendFormat": "Dossiers completed"
    }
  ],
  "type": "stat",
  "displayMode": "number"
}
```

#### Panel 4: Error Log
```json
{
  "title": "Recent Errors",
  "targets": [
    {
      "expr": "benavora_agent_events_logged_total{severity='error'} or benavora_agent_events_logged_total{severity='critical'}",
      "legendFormat": "{{ agent_id }}: {{ event_type }}"
    }
  ],
  "type": "table"
}
```

### Grafana Setup
```bash
docker run -d \
  --name grafana \
  -p 3000:3000 \
  -e GF_SECURITY_ADMIN_PASSWORD=admin \
  grafana/grafana:latest

# Access: http://localhost:3000
# Default creds: admin / admin
# Add Prometheus data source: http://prometheus:9090
# Import dashboard: dashboard.json (from spec above)
```

---

## PART 4: ALERT ROUTING

### Slack Integration
```yaml
# In prometheus alertmanager config
route:
  receiver: 'benavora-alerts'
  group_by: ['severity', 'alertname']

receivers:
  - name: 'benavora-alerts'
    slack_configs:
      - api_url: 'https://hooks.slack.com/services/YOUR/WEBHOOK/URL'
        channel: '#benavora-alerts'
        title: 'Benavora Alert: {{ .GroupLabels.alertname }}'
        text: '{{ range .Alerts }}{{ .Annotations.description }}{{ end }}'
        send_resolved: true
```

---

## PART 5: STRUCTURED LOGGING

### Logger Configuration
File: `src/lib/observability/logger.ts`

```typescript
import winston from 'winston';

export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' }),
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.printf(({ timestamp, level, message, ...meta }) => {
          return `${timestamp} [${level}] ${message} ${Object.keys(meta).length ? JSON.stringify(meta) : ''}`;
        })
      )
    })
  ]
});

export function logEvent(type: string, data: any, level = 'info') {
  logger.log(level, `${type}`, data);
}
```

### Usage
```typescript
logEvent('agent_started', {
  agentId: 'BEN-SUP-01',
  prospectId: prospect.id,
  researchRunId: run.id,
  timestamp: new Date().toISOString()
});

logEvent('integration_error', {
  integrationName: 'sam.gov',
  statusCode: 429,
  message: 'Rate limit exceeded',
  retryAfter: 100
}, 'warn');
```

---

## DEPLOYMENT CHECKLIST

- [ ] Prometheus installed + running (port 9090)
- [ ] `/api/metrics` endpoint live
- [ ] Prometheus scraping `/api/metrics` successfully
- [ ] Alert rules loaded in Prometheus
- [ ] Grafana installed + running (port 3000)
- [ ] Prometheus data source configured in Grafana
- [ ] Dashboard imported + displaying live data
- [ ] Slack webhook configured for alerts
- [ ] Test alert triggered + received in Slack
- [ ] Logging to files configured (logs/combined.log)
- [ ] Log rotation configured (don't fill disk)

---

**[END OF OBSERVABILITY_CONFIGURATION_GUIDE]**
