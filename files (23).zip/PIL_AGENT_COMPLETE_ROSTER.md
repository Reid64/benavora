# PIL_AGENT_COMPLETE_ROSTER — All 47 Benavora Intelligence Agents
**Date:** 2026-09-01  
**Status:** COMPLETE — All 47 agents built, tested, deployed  
**Total Agents:** 47 across 9 families

---

## FAMILY 1: SUP (Support/Foundation) — 6 Agents

### BEN-SUP-01: Entity Verification Agent
**Status:** ✅ COMPLETE  
**Purpose:** Verify prospect legal status, incorporation, tax status, foundation type  
**Input:**
- prospect: { name, website, ein?, headquarters_city, headquarters_state }
- organization: { mission_statement, programs[] }

**Output:** pil_prospect_dossiers.sup_*
```typescript
sup_entity_verified: boolean,
sup_legal_name: string,
sup_alternate_names: string[],
sup_incorporation_date: date,
sup_jurisdiction: string,
sup_ein: string,
sup_tax_status: string,
sup_501c3_verified: boolean,
sup_foundation_type: "private"|"community"|"corporate"|"family"|"operating"|"unknown",
sup_grant_size_range: { min: number, max: number },
sup_annual_giving_budget: numeric,
sup_geographic_focus: string[],
sup_cause_priorities: string[],
sup_submission_preferences: { online?: boolean, mail?: boolean, proposal_format?: string[] },
sup_application_cycle: string,
sup_findings: { verified_sources: string[], confidence: 0-1, evidence_chain: [] },
sup_confidence: 0.0-1.0,
sup_last_verified_at: timestamptz
```

**Data Sources:**
- IRS: EIN lookup, 501(c)3 status, annual returns (Form 990)
- Secretary of State: incorporation records
- Foundation Directory Online: funder profile
- Prospect website: stated mission, giving guidelines
- SEC EDGAR: for corporate foundations

**Error Handling:**
- EIN not found: mark as "likely nonprofit, needs verification"
- 501(c)3 status unknown: flag as "tax status unverified, high risk"
- No website: cannot verify, confidence low
- Website blocked (robots.txt): skip website sources, use IRS only

**Dependencies:** None (first agent)

---

### BEN-SUP-02: Foundation Assets & Giving Capacity Agent
**Status:** ✅ COMPLETE  
**Purpose:** Determine foundation asset base, annual giving capacity, giving trends  
**Input:**
- prospect_id: uuid
- sup_findings: from BEN-SUP-01
- sup_ein: string

**Output:** pil_prospect_dossiers.sup_*
```typescript
sup_annual_giving_budget: numeric (actual or estimated),
sup_giving_trend: "rising"|"stable"|"declining"|"unknown",
sup_recent_grants: string[] (known award descriptions),
sup_application_closed_recently: boolean,
sup_findings: { asset_sources: [], giving_history: [], capacity_estimate: {} }
```

**Data Sources:**
- IRS Form 990-PF (private foundation returns): assets, distributions, grant details
- GuideStar/Candid: giving history
- Foundation Center: latest awards
- Prospect website: grant announcements
- LinkedIn: recent news

**Calculations:**
- Foundation Assets: from 990-PF line 1c (total assets)
- Annual Giving Capacity: = assets × 0.05 (5% annual distribution requirement for private foundations)
- Giving Trend: year-over-year change in Form 990 distributions

**Error Handling:**
- 990-PF not found: flag "unverified capacity" + use website hints
- No giving history: assume minimum capacity (foundations must give 5% of assets)
- Outdated data (>2 years): flag "data stale, needs refresh"

**Dependencies:** BEN-SUP-01 (needs verified EIN)

---

### BEN-SUP-03: Grant Program Details Agent
**Status:** ✅ COMPLETE  
**Purpose:** Identify specific grant programs, focus areas, award amounts, application requirements  
**Input:**
- prospect_id: uuid
- sup_findings: from BEN-SUP-01/02
- organization: { cause[], programs[], geography }

**Output:**
```typescript
sup_grant_programs: [
  {
    program_name: string,
    focus_area: string[],
    min_award: number,
    max_award: number,
    avg_award: number,
    application_deadline: string|null,
    application_cycle: string,
    application_requirements: { proposal_length?: string, budget_required?: boolean, ... }
  }
],
sup_findings: { programs_found: integer, data_completeness: 0-1 }
```

**Data Sources:**
- Foundation website: grants page, guidelines PDF
- GuideStar: grant program descriptions
- Foundation Center: detailed program profiles
- Recent 990-PF: actual grants made (last 100 grants)

**Logic:**
- Extract grant program names, focus areas, award ranges
- Cross-reference with organization's cause/program focus
- Identify match score (0-1): how well do funder programs align with org?
- Identify application requirements (deadline, format, length, etc)

**Error Handling:**
- No grants page: flag "grant programs unknown"
- Generic granting (no specific programs): capacity exists but priorities unclear
- Application requirements incomplete: flag "need to call for guidelines"

**Dependencies:** BEN-SUP-01/02 (needs verified entity + capacity)

---

### BEN-SUP-04: Geographic & Cause Focus Agent
**Status:** ✅ COMPLETE  
**Purpose:** Determine geographic restrictions, cause priorities, target populations  
**Input:**
- prospect_id: uuid
- sup_findings: from prior SUP agents
- sup_cause_priorities: string[] (from SUP-01)
- organization: { geography[], causes[], populations[] }

**Output:**
```typescript
sup_geographic_focus: [
  {
    region: "United States"|"Global"|"State"|"Metro Area",
    specific: string (e.g., "California", "San Francisco Bay Area"),
    focus_level: "primary"|"secondary"|"tertiary"
  }
],
sup_cause_priorities: [
  {
    cause: string (e.g., "housing", "education", "health"),
    specificity: string (e.g., "affordable housing", "K-12", "mental health"),
    priority_level: "primary"|"secondary"
  }
],
sup_population_focus: string[] (e.g., "homeless", "foster youth", "seniors"),
sup_geographic_match: 0.0-1.0 (org's geography vs funder's),
sup_cause_match: 0.0-1.0 (org's cause vs funder's),
sup_findings: { restrictions: string[], alignment_notes: string }
```

**Data Sources:**
- Foundation website guidelines
- IRS 990-PF: schedule of grants (shows geographic/cause patterns)
- GuideStar: stated geographic limitations
- Recent awards: actual geographic/cause distribution

**Logic:**
- Extract stated geographic focus (US, global, specific states, metro areas)
- Extract stated cause priorities (housing, education, health, etc)
- Calculate alignment score with organization's geography/causes
- Identify restrictions (only CA, only nonprofits, etc)

**Error Handling:**
- No geographic restriction: assume national
- Vague cause language: extract keywords, flag for manual review
- Recent awards contradict stated focus: flag inconsistency

**Dependencies:** BEN-SUP-01/02/03 (needs complete SUP profile)

---

### BEN-SUP-05: Submission Guidelines & Process Agent
**Status:** ✅ COMPLETE  
**Purpose:** Document application process, submission method, required documents, restrictions  
**Input:**
- prospect_id: uuid
- sup_grant_programs: from BEN-SUP-03

**Output:**
```typescript
sup_submission_preferences: {
  online_application: boolean,
  mail_submission: boolean,
  email_submission: boolean,
  application_url: string|null,
  application_contact_email: string|null,
  application_contact_phone: string|null,
  application_contact_name: string|null
},
sup_required_documents: string[] (
  "organizational-mission-statement",
  "501c3-determination-letter",
  "recent-audit",
  "budget-narrative",
  "impact-metrics",
  ...
),
sup_restrictions: string[] (
  "no-support-for-individuals",
  "only-organizations-with-3yr-history",
  "501c3-required",
  "no-religious-organizations",
  ...
),
sup_application_cycle: {
  open_date: date|null,
  deadline: date|null,
  frequency: "rolling"|"annual"|"semi-annual",
  decision_timeline: string (e.g., "90 days")
},
sup_findings: { submission_clarity: 0-1, completeness: 0-1 }
```

**Data Sources:**
- Foundation website: guidelines, application form
- Application form itself: required fields
- Recent announcements: application dates
- Prospect contact: for unclear guidelines

**Critical Information:**
- Is application online or paper?
- What documents are required?
- What is the deadline?
- How often does it accept applications?
- Are there any disqualifying restrictions?
- How long until decision?

**Error Handling:**
- No application process found: flag "currently not accepting applications"
- Unclear submission method: provide all contact options
- Outdated deadline information: flag "verify before applying"
- Conflicting information: document sources, note discrepancy

**Dependencies:** BEN-SUP-03 (needs grant programs)

---

### BEN-SUP-06: Funder Contact & Decision-Maker Agent
**Status:** ✅ COMPLETE  
**Purpose:** Identify key staff, decision-makers, program officers, contact information  
**Input:**
- prospect_id: uuid
- prospect: { name, website }
- sup_grant_programs: from BEN-SUP-03

**Output:**
```typescript
sup_decision_makers: [
  {
    name: string,
    title: string (e.g., "Program Officer", "Executive Director", "Grant Manager"),
    email: string|null,
    phone: string|null,
    program_focus: string (which programs they oversee),
    linkedin_url: string|null,
    biography: string|null,
    tenure: string|null
  }
],
sup_general_contact: {
  phone: string|null,
  email: string|null,
  mailing_address: string|null,
  website: string
},
sup_findings: { contact_completeness: 0-1, recency: date|null }
```

**Data Sources:**
- Foundation website: staff directory
- LinkedIn: company page, employee profiles
- Guidestar: staff listings
- IRS 990: board members
- Recent news articles: personnel announcements

**Priority Information:**
1. Program Officer or Manager for relevant grant program (direct contact best)
2. Program Director or VP of Grants
3. Executive Director
4. General inquiry email/phone (fallback)

**Error Handling:**
- Key staff not found: provide general contact only
- Outdated staff listings: flag "verify before reaching out"
- No email/phone: provide website + general contact
- Staff recently changed: document when/who/transition

**Dependencies:** BEN-SUP-03 (needs grant programs to identify relevant staff)

---

## FAMILY 2: DIS (Discovery/Sources) — 8 Agents

### BEN-DIS-01: Web Discovery & Public Profile Agent
**Status:** ✅ COMPLETE  
**Purpose:** Discover funder online presence, public statements, recent activity  
**Input:**
- prospect: { name, website }

**Output:**
```typescript
dis_web_presence: {
  website_exists: boolean,
  website_last_updated: date|null,
  social_media: { linkedin?: string, twitter?: string, facebook?: string, instagram?: string },
  press_releases: integer (count in last 2 years),
  news_mentions: integer (count in last 2 years)
},
dis_public_statements: [
  {
    statement: string,
    source: string,
    date: date,
    category: "mission"|"strategy"|"priorities"|"restrictions",
    sentiment: "positive"|"neutral"|"negative"
  }
],
dis_findings: { web_presence_strength: 0-1, recency: date|null }
```

**Data Sources:**
- Google Search: recent articles, press releases
- LinkedIn: company page, posts, updates
- Twitter/X: official account, tweets
- Foundation website: homepage, about page, blog
- Press release databases

**Logic:**
- Search for funder name + keywords
- Identify official website
- Check social media presence
- Count recent public statements (last 2 years)
- Classify statements by category (mission, strategy, priorities)

**Error Handling:**
- Website not found: possible defunct or no online presence
- Outdated website: flag "may not be actively funding"
- No social media: some foundations deliberately private
- Conflicting public statements: document discrepancy

**Dependencies:** None (first DIS agent)

---

### BEN-DIS-02: Recent News & Announcements Agent
**Status:** ✅ COMPLETE  
**Purpose:** Identify recent funding announcements, organizational changes, strategy shifts  
**Input:**
- prospect: { name }
- dis_web_presence: from BEN-DIS-01

**Output:**
```typescript
dis_recent_announcements: [
  {
    date: date,
    headline: string,
    announcement_type: "funding_round"|"strategy_shift"|"partnership"|"grant_award"|"leadership_change",
    summary: string,
    source_url: string,
    relevance: 0-1 (to nonprofit funding)
  }
],
dis_strategic_shifts: [
  {
    date: date,
    change: string (e.g., "expanding focus to climate change"),
    evidence: string[] (quotes, links)
  }
],
dis_recent_awards: [
  {
    grantee: string,
    amount: numeric|null,
    date: date,
    program: string,
    focus_area: string
  }
],
dis_findings: { news_activity: "high"|"medium"|"low", last_activity: date|null }
```

**Data Sources:**
- Google News: recent articles about funder
- Foundation website: news/updates section
- GuideStar: recent announcements
- Candid/Foundation Center: grant announcements
- LinkedIn news feed

**Critical Signals:**
- Strategic pivot (change in focus areas)
- New leadership (executive director, VP of grants)
- Increased funding (raise, endowment growth)
- Decreased funding (budget cuts, closure of programs)
- New partnerships (alignment signals)
- Recent grant awards (reveals actual priorities)

**Error Handling:**
- No recent news: possible dormant foundation
- News contradicts stated guidelines: flag discrepancy
- Announcement date uncertain: flag for verification

**Dependencies:** BEN-DIS-01 (needs web presence to search)

---

### BEN-DIS-03: Board & Leadership Analysis Agent
**Status:** ✅ COMPLETE  
**Purpose:** Analyze board composition, leadership experience, potential connection points  
**Input:**
- prospect: { name }
- sup_decision_makers: from BEN-SUP-06

**Output:**
```typescript
dis_board_members: [
  {
    name: string,
    title: string,
    company_affiliation: string|null,
    experience_areas: string[] (e.g., "nonprofit management", "finance", "real estate"),
    tenure_on_board: integer (years)|null,
    linkedin_url: string|null,
    potential_connections: { connection_type: string, strength: 0-1 }
  }
],
dis_executive_team: [
  {
    name: string,
    title: string,
    background: string,
    tenure: integer (years)|null
  }
],
dis_board_diversity: {
  gender_diversity: 0-1,
  racial_diversity: 0-1,
  professional_diversity: 0-1 (range of professional backgrounds)
},
dis_findings: { board_engagement: 0-1, alignment_potential: 0-1 }
```

**Data Sources:**
- Foundation website: board page
- LinkedIn: individual profiles, search for board members
- IRS 990: Schedule B (board members and officers)
- News articles: leadership announcements
- Prospect website

**Analysis:**
- Who are the board members?
- What is their professional background?
- How long have they been on the board?
- Do they have relevant expertise (nonprofit, the org's cause area)?
- Is there geographic diversity?
- Are there known connection points (alumni, previous employer)?

**Error Handling:**
- Board not listed: flag "transparency concern"
- Board members outdated: flag "verify before outreach"
- Limited diversity: note without judgment (informational)

**Dependencies:** BEN-DIS-01 (needs web presence), BEN-SUP-06 (for staff context)

---

### BEN-DIS-04: Competitor & Similar Grantee Analysis Agent
**Status:** ✅ COMPLETE  
**Purpose:** Identify organizations receiving grants from same funder (reveals strategy, capacity, fit)  
**Input:**
- prospect_id: uuid
- sup_geographic_focus: from BEN-SUP-04
- sup_cause_priorities: from BEN-SUP-04
- organization: { cause[], geography[] }

**Output:**
```typescript
dis_recent_grantees: [
  {
    grantee_name: string,
    grant_amount: numeric|null,
    grant_date: date,
    grant_program: string,
    grantee_cause_focus: string[] (inferred),
    grantee_geography: string (inferred)
  }
],
dis_competitor_analysis: {
  similar_organizations: [
    {
      name: string,
      similarity_score: 0-1,
      reason: string (e.g., "same cause + geography")
    }
  ],
  funding_patterns: {
    average_grant_size: numeric,
    most_common_cause: string,
    most_common_geography: string,
    funding_frequency: "annual"|"project-based"|"ongoing"
  }
},
dis_market_position: {
  market_saturation: 0-1 (0=underserved, 1=overcrowded),
  differentiation_opportunity: string
},
dis_findings: { pattern_clarity: 0-1, sample_size: integer (grantees analyzed) }
```

**Data Sources:**
- IRS 990-PF: schedule of grants (last 5 years)
- Funder website: grant recipients list
- GuideStar: grants list
- Foundation Center: funding data

**Logic:**
- Extract all grants made in last 5 years
- Categorize by cause, geography, amount
- Identify patterns (what does funder actually fund?)
- Compare org to similar recent grantees
- Calculate market saturation (how many similar orgs already funded?)

**Key Insight:** What funder SAYS it funds vs what it ACTUALLY funds often differ. This agent finds the truth.

**Error Handling:**
- Grant list incomplete: flag "data may be incomplete"
- No recent grants: flag "foundation may be dormant"
- Ambiguous grantee names: flag "verify grantee identity"

**Dependencies:** BEN-SUP-04 (needs geographic/cause focus), BEN-DIS-02 (for recent awards)

---

### BEN-DIS-05: Media Sentiment & Reputation Agent
**Status:** ✅ COMPLETE  
**Purpose:** Assess funder reputation, controversies, media sentiment  
**Input:**
- prospect: { name }
- dis_recent_announcements: from BEN-DIS-02

**Output:**
```typescript
dis_media_sentiment: "very_positive"|"positive"|"neutral"|"negative"|"very_negative",
dis_reputation_score: 0-1,
dis_controversies: [
  {
    date: date,
    issue: string,
    description: string,
    resolution: string|null,
    severity: "low"|"medium"|"high"
  }
],
dis_negative_signals: string[] (
  e.g., "CEO scandal", "failed foundation", "grant scandal", "misuse of funds"
),
dis_positive_signals: string[] (
  e.g., "innovative granting", "high transparency", "strong nonprofit partnerships"
),
dis_findings: { sentiment_confidence: 0-1, data_recency: date }
```

**Data Sources:**
- Google News: negative articles
- Chronicle of Philanthropy: foundation news/controversies
- Twitter/X: public criticism
- GuideStar: organization ratings/reviews
- Foundation Center: risk alerts
- LinkedIn: employee reviews

**Red Flags to Identify:**
- Leader scandal/indictment
- Misuse of funds
- Failed grants (grantees didn't deliver)
- Grant program closure without explanation
- Labor disputes
- Tax issues
- Controversial giving (funding debated causes)

**Green Flags to Identify:**
- High transparency (open application process)
- Strong nonprofit partnerships
- Innovative granting (flexibility, collaborative)
- Quick decision turnaround
- Supportive (not just funding, also mentoring)

**Error Handling:**
- Outdated controversies: note date, assess if resolved
- Unverified claims: flag as "unconfirmed" not facts
- Partisan bias in coverage: note source bias

**Dependencies:** BEN-DIS-01/02 (needs web presence + recent news)

---

### BEN-DIS-06: Financial Health & Stability Agent
**Status:** ✅ COMPLETE  
**Purpose:** Assess funder financial stability, funding trends, risk of closure  
**Input:**
- prospect_id: uuid
- sup_annual_giving_budget: from BEN-SUP-02
- sup_ein: string

**Output:**
```typescript
dis_financial_health: "excellent"|"good"|"stable"|"declining"|"at_risk"|"unknown",
dis_financial_metrics: {
  total_assets: numeric|null (from latest 990-PF),
  annual_revenue: numeric|null,
  annual_distributions: numeric|null (grants given),
  distribution_rate: 0-1 (distributions / assets),
  endowment_growth_trend: "growing"|"stable"|"declining"|null,
  years_of_data: integer
},
dis_financial_projections: {
  estimated_funding_in_2_years: numeric|null,
  risk_of_funding_reduction: "low"|"medium"|"high"|"unknown",
  risk_factors: string[] (e.g., "endowment down 20%", "reduced giving last 2 years")
},
dis_findings: { data_quality: 0-1, confidence: 0-1 }
```

**Data Sources:**
- IRS 990-PF: assets, distributions, endowment value (last 3-5 years)
- GuideStar: financial metrics
- Foundation annual reports: financial statements
- Stock market data (if foundation holds publicly traded securities)

**Key Calculations:**
- Distribution Rate = annual grants / total assets (should be ~5% for private foundations)
- Endowment Growth = (current assets - prior year assets) / prior year assets
- Sustainability = endowment trend + distribution rate

**Risk Signals:**
- Endowment declining > 10% year-over-year
- Distribution rate > 10% (unsustainable, depleting endowment)
- Skipped distributions (missed required 5% payout)
- Asset decline without explanation

**Error Handling:**
- 990-PF not available: use public sources + flag "unverified"
- Data > 2 years old: flag "stale data, likely outdated"
- Endowment fluctuation (stock market): normalize and note

**Dependencies:** BEN-SUP-02 (needs EIN + giving budget context)

---

### BEN-DIS-07: Technology & Innovation Stack Agent
**Status:** ✅ COMPLETE  
**Purpose:** Assess funder's technology adoption, online application capability, integration readiness  
**Input:**
- prospect: { website }
- sup_submission_preferences: from BEN-SUP-05

**Output:**
```typescript
dis_tech_stack: {
  has_online_application: boolean,
  application_platform: string|null (e.g., "Proposify", "Fluxx", "SalesForce", "custom"),
  application_complexity: "simple"|"moderate"|"complex",
  api_available: boolean,
  webhooks_available: boolean,
  data_format: "JSON"|"XML"|"CSV"|"PDF"|"unknown"
},
dis_digital_maturity: "legacy"|"basic"|"intermediate"|"advanced"|"unknown",
dis_integration_readiness: {
  can_auto_fill_application: boolean,
  can_submit_electronically: boolean,
  can_track_status_electronically: boolean,
  api_documentation_available: boolean
},
dis_findings: { tech_assessment: 0-1, automation_potential: 0-1 }
```

**Data Sources:**
- Foundation website: application page, tech used
- LinkedIn company page: tech mentions
- G2/Capterra: tools used
- Public API documentation
- Test account creation: assess usability

**Assessment:**
- Is application online or paper?
- Is platform modern (Fluxx, Proposify) or custom?
- Can it be auto-filled by software?
- Is there an API for integration?
- Is there webhook support for real-time updates?

**This Agent Informs:** Whether Benavora can auto-fill + submit forms

**Error Handling:**
- Platform unclear: attempt to create test account to assess
- API not documented: contact funder for API access
- Very old technology: flag "may have integration challenges"

**Dependencies:** BEN-SUP-05 (needs submission preferences)

---

### BEN-DIS-08: Risk & Compliance Assessment Agent
**Status:** ✅ COMPLETE  
**Purpose:** Identify legal/compliance risks, restrictions, due diligence requirements  
**Input:**
- prospect_id: uuid
- prospect: { name, ein }
- dis_controversies: from BEN-DIS-05
- sup_restrictions: from BEN-SUP-05

**Output:**
```typescript
dis_compliance_requirements: {
  requires_audit: boolean,
  requires_annual_report: boolean,
  requires_501c3: boolean,
  requires_years_of_operation: integer|null (minimum years established),
  requires_financial_statements: boolean,
  other_requirements: string[]
},
dis_legal_restrictions: [
  {
    restriction: string,
    severity: "low"|"medium"|"high",
    workaround: string|null
  }
],
dis_due_diligence_risk: "low"|"medium"|"high"|"unknown",
dis_risk_factors: string[] (
  e.g., "funder on sanctions list?", "restricted funding for lobbying?"
),
dis_compliance_score: 0-1 (org's likelihood of meeting all requirements),
dis_findings: { restrictions_clarity: 0-1 }
```

**Data Sources:**
- Foundation website: eligibility requirements
- IRS: sanctions list, charity verification
- OFAC: sanctions screening
- Foundation guidelines: legal restrictions
- State AG database: complaints/investigations

**Critical Checks:**
- Is nonprofit on IRS sanctions list?
- Is nonprofit 501(c)(3)?
- Does nonprofit meet age/revenue requirements?
- Are there content restrictions (no lobbying, no religious)?
- Are there geographic restrictions?
- Are there cause restrictions?

**Error Handling:**
- Requirements unclear: request clarification
- Restrictions contradictory: flag for manual review
- Sanctions check fails: automatic disqualification

**Dependencies:** All prior DIS agents (comprehensive risk assessment)

---

## FAMILY 3: INT (Intelligence/Alignment) — 10 Agents

### BEN-INT-01: Mission & Cause Alignment Agent
**Status:** ✅ COMPLETE  
**Purpose:** Compare funder's stated cause priorities with nonprofit's mission/programs  
**Input:**
- organization: { mission_statement, programs[], causes[] }
- sup_cause_priorities: from BEN-SUP-04
- funder_cause_priorities: from BEN-DIS-04

**Output:**
```typescript
int_cause_alignment: {
  org_primary_cause: string,
  funder_primary_cause: string,
  alignment_score: 0-1 (0=no overlap, 1=perfect match),
  alignment_detail: [
    {
      org_cause: string,
      funder_cause: string,
      overlap_score: 0-1,
      reason: string
    }
  ],
  misalignment_factors: string[] (areas of non-overlap),
  alignment_strength: "perfect"|"strong"|"moderate"|"weak"|"none"
},
int_mission_affinity: 0-1 (0=contradictory, 1=perfectly aligned),
int_findings: { cause_data_quality: 0-1 }
```

**Logic:**
- Extract org's primary cause (housing, education, health, etc)
- Extract funder's primary cause from sup data
- Calculate overlap (0-1)
- Identify secondary causes and their alignment
- Assess mismatch factors (if any)

**Example:**
```
Organization: "We provide job training for homeless populations"
Funder Priorities: Primary=housing, Secondary=workforce development

Alignment:
- Homeless population: MATCH (funder funds housing for homeless)
- Job training: PARTIAL MATCH (funder funds workforce dev as secondary)
- Overall Alignment: 0.75 (strong but not perfect)
```

**Error Handling:**
- Vague mission statement: ask for clarification
- Too broad priorities: rank primary vs secondary
- Contradictory causes: flag and request org clarification

**Dependencies:** BEN-SUP-04 (needs cause priorities), BEN-DIS-04 (needs actual grantee causes)

---

### BEN-INT-02: Geographic Alignment Agent
**Status:** ✅ COMPLETE  
**Purpose:** Match nonprofit's service geography with funder's geographic focus  
**Input:**
- organization: { headquarters_city, headquarters_state, service_areas[] }
- sup_geographic_focus: from BEN-SUP-04

**Output:**
```typescript
int_geography_alignment: {
  org_primary_geography: string (e.g., "San Francisco Bay Area"),
  funder_primary_geography: string,
  alignment_score: 0-1,
  alignment_type: "exact"|"regional"|"state"|"national"|"international"|"none",
  geographic_detail: [
    {
      org_service_area: string,
      funder_focus_area: string,
      overlap: "exact"|"regional"|"partial"|"none"
    }
  ],
  geographic_expansion_opportunity: 0-1 (org could expand to match funder)
},
int_findings: { geography_clarity: 0-1 }
```

**Logic:**
- Map org's service areas to funder's geographic focus
- Calculate overlap at different geographic levels (exact city, state, region, national)
- Identify expansion opportunities (org could serve funder's geography)

**Example:**
```
Organization: Serves Oakland, CA (focused)
Funder: Primary=Bay Area, Secondary=California

Alignment:
- Oakland: EXACT MATCH (within Bay Area)
- Funder could also fund: other Bay Area orgs or California orgs
- Alignment Score: 1.0 (perfect geographic match)
- Expansion Opportunity: 0.3 (could expand to other Bay Area cities)
```

**Error Handling:**
- Service areas vague: ask for specific cities/states
- International funder + local org: flag "geographic mismatch"
- No geographic restriction: assume national

**Dependencies:** BEN-SUP-04 (needs funder geographic focus)

---

### BEN-INT-03: Strategy & Theory of Change Alignment Agent
**Status:** ✅ COMPLETE  
**Purpose:** Compare funder's strategic approach with org's approach  
**Input:**
- organization: { theory_of_change, programs[], approach_statement }
- dis_strategic_shifts: from BEN-DIS-02
- dis_positive_signals: from BEN-DIS-05
- recent_grantees: from BEN-DIS-04

**Output:**
```typescript
int_strategy_alignment: {
  funder_approach: string (e.g., "direct service", "systems change", "research"),
  org_approach: string,
  approach_compatibility: 0-1,
  funder_trend: "expanding"|"stable"|"narrowing",
  org_alignment_with_trend: boolean
},
int_innovation_fit: 0-1 (is org innovative? does funder value innovation?),
int_collaborative_potential: 0-1 (does funder collaborate? does org?),
int_funding_model_fit: {
  funder_preference: "project_based"|"operating_support"|"endowment"|"mixed"|"unknown",
  org_need: "project_based"|"operating_support"|"endowment"|"mixed",
  compatibility: 0-1
},
int_findings: { strategy_clarity: 0-1, vision_alignment: 0-1 }
```

**Logic:**
- Identify funder's approach (direct service, systems change, research, capacity building)
- Identify org's approach
- Assess compatibility
- Is funder expanding or narrowing their focus?
- Is org aligned with funder's trajectory?
- Does funder value innovation? Is org innovative?

**Example:**
```
Funder: "We invest in innovative solutions to housing affordability" (systems change focus)
Organization: "We provide emergency shelter + job training" (direct service focus)

Alignment:
- Funder values innovation: YES
- Org is innovative: MODERATE (traditional approach with new job training program)
- Strategy Compatibility: 0.5 (some misalignment, funder prefers systemic)
- Implication: Could strengthen pitch by emphasizing systems change aspect
```

**Error Handling:**
- Org's strategy unclear: ask for theory of change document
- Funder's approach changing: use recent announcements as signal
- Mismatch detected: note but don't disqualify (many exceptions possible)

**Dependencies:** BEN-DIS-02 (needs strategy shifts), BEN-DIS-04/05 (context)

---

### BEN-INT-04: Population Alignment Agent
**Status:** ✅ COMPLETE  
**Purpose:** Match nonprofit's target population with funder's focus populations  
**Input:**
- organization: { target_populations[] }
- sup_population_focus: from BEN-SUP-04

**Output:**
```typescript
int_population_alignment: {
  org_primary_population: string (e.g., "homeless adults"),
  funder_primary_population: string|null,
  population_match: 0-1,
  population_detail: [
    {
      org_population: string,
      funder_population: string|null,
      overlap: 0-1
    }
  ]
},
int_vulnerable_population_signal: boolean (is org serving especially vulnerable?),
int_findings: { population_data_quality: 0-1 }
```

**Logic:**
- Extract org's target populations (homeless, foster youth, seniors, etc)
- Extract funder's stated population focus
- Calculate alignment

**Example:**
```
Organization: Serves "homeless adults with mental illness"
Funder: "We support homeless populations"

Alignment:
- Base population (homeless): MATCH
- Sub-population (mental illness): Not specifically mentioned by funder
- But likely alignment (mental health is common nonprofit focus)
- Alignment Score: 0.85 (strong match on main population)
```

**Error Handling:**
- Population not specified: infer from programs
- Funder has no stated population focus: assume inclusive
- Rare population: may reduce score but not disqualify

**Dependencies:** BEN-SUP-04 (needs funder population focus)

---

### BEN-INT-05: Scale & Maturity Alignment Agent
**Status:** ✅ COMPLETE  
**Purpose:** Assess if org's scale/maturity matches funder's expectations  
**Input:**
- organization: { annual_budget, years_established, staff_size, service_volume }
- sup_grant_programs: from BEN-SUP-03

**Output:**
```typescript
int_scale_alignment: {
  org_annual_budget: numeric,
  org_maturity: "startup"|"growing"|"established"|"mature",
  funder_preferred_scale: string|null (inferred from grant sizes),
  scale_compatibility: 0-1,
  org_readiness_for_grant_amount: 0-1
},
int_capacity_concerns: [
  {
    concern: string,
    severity: "low"|"medium"|"high"
  }
],
int_findings: { scale_data_quality: 0-1 }
```

**Logic:**
- Calculate org's annual budget
- Classify as startup (< $500K), growing ($500K-$2M), established ($2M-$10M), mature (> $10M)
- Infer funder's preferred scale from average grant size
- Assess compatibility

**Example:**
```
Organization: Annual budget $800K (small, growing)
Funder: Average grant $150K (suggests they fund organizations $500K-$3M)

Alignment:
- Org scale: GOOD (within funder's preferred range)
- Org maturity: Good (established enough to manage grant)
- Capacity concern: MODERATE (large grant relative to budget, may stretch)
- Score: 0.75 (acceptable but close to capacity limit)
```

**Error Handling:**
- Org budget unknown: ask organization
- Funder's preferred scale unclear: use average grant size as proxy
- Concern detected: not disqualifying but important context

**Dependencies:** BEN-SUP-03 (needs grant program sizes)

---

### BEN-INT-06: Theory of Change Depth & Evidence Agent
**Status:** ✅ COMPLETE  
**Purpose:** Assess org's theory of change and evidence vs funder's expectations  
**Input:**
- organization: { theory_of_change, impact_metrics[], evaluation_capacity }
- dis_positive_signals: from BEN-DIS-05 (does funder value evidence?)

**Output:**
```typescript
int_theory_of_change_strength: 0-1,
int_evidence_orientation: {
  org_commitment_to_evidence: 0-1,
  funder_evidence_expectations: "high"|"moderate"|"low"|"unknown",
  compatibility: 0-1
},
int_evaluation_capacity: 0-1 (does org have capacity to measure impact?),
int_metric_alignment: {
  org_primary_metric: string,
  funder_valuation_of_metric: "highly_valued"|"valued"|"acceptable"|"unknown",
  alignment: 0-1
},
int_findings: { evidence_data_quality: 0-1 }
```

**Logic:**
- Does org have clear theory of change?
- Does org measure outcomes vs outputs?
- Does org have external evaluation?
- Does funder emphasize evidence-based grantmaking?
- Are org's metrics what funder cares about?

**Example:**
```
Organization: "We track participants served" (output metric, no outcome evaluation)
Funder: Stated as "evidence-based" funder, emphasizes long-term outcomes

Alignment:
- Theory of Change: Present but basic
- Evidence Orientation: Org is output-focused, Funder is outcome-focused
- Compatibility: 0.4 (significant mismatch, would need to strengthen)
- Recommendation: Org needs to develop outcome metrics before applying
```

**Error Handling:**
- Org has no TOC: flag "will likely need to develop before grant"
- Funder's evidence requirements unclear: look at grantee publications
- Mismatch detected: note as requirement for pre-application work

**Dependencies:** BEN-DIS-05 (needs funder's value signals)

---

### BEN-INT-07: Cultural & Values Alignment Agent
**Status:** ✅ COMPLETE  
**Purpose:** Assess cultural fit, values alignment, relationship compatibility  
**Input:**
- organization: { mission_statement, values[], board_composition }
- dis_board_members: from BEN-DIS-03
- dis_positive_signals: from BEN-DIS-05

**Output:**
```typescript
int_values_alignment: {
  org_core_values: string[],
  funder_inferred_values: string[],
  values_overlap: 0-1,
  values_detail: [
    {
      value: string,
      org_commitment: 0-1,
      funder_commitment: 0-1,
      alignment: 0-1
    }
  ]
},
int_cultural_fit: 0-1,
int_relationship_culture: {
  funder_collaborative: boolean,
  funder_transactional: boolean,
  org_collaborative_preference: boolean,
  compatibility: 0-1
},
int_red_flags: string[] (e.g., "org controversial, funder conservative"),
int_findings: { values_clarity: 0-1 }
```

**Logic:**
- Extract org's stated values
- Infer funder values from board members, giving history, positive/negative signals
- Assess overlap
- Is relationship likely to be collaborative or transactional?
- Are there cultural red flags?

**Example:**
```
Organization: "LGBTQ+ affirming organization for homeless LGBTQ+ youth"
Funder: Conservative family foundation, some board members with religious affiliations

Alignment:
- Values Overlap: Potentially low (depends on funder's actual openness)
- Risk Flag: Possible cultural misalignment on LGBTQ+ issues
- Recommendation: Research funder's actual track record with LGBTQ+ organizations before outreach
- Outcome: Either clear fit or clear misfit (medium not likely)
```

**Error Handling:**
- Values unclear: ask organization for clarification
- Inferred values based on signals: note confidence level
- Red flag detected: note but don't disqualify (often worth exploring)

**Dependencies:** BEN-DIS-03/05 (needs board/signal context)

---

### BEN-INT-08: Financial Alignment Agent
**Status:** ✅ COMPLETE  
**Purpose:** Assess if org's financial health/practices match funder's expectations  
**Input:**
- organization: { annual_budget, audit_status, financial_reserves, admin_ratio }
- dis_financial_health: from BEN-DIS-06

**Output:**
```typescript
int_financial_alignment: {
  org_audit_status: "audited"|"reviewed"|"unaudited"|"unknown",
  org_financial_transparency: 0-1,
  org_admin_ratio: 0-1 (overhead percentage),
  funder_expectations: "high_standard"|"moderate"|"low"|"unknown",
  compatibility: 0-1
},
int_financial_health_parity: 0-1 (is org as financially healthy as funder?),
int_financial_maturity: {
  has_reserves: boolean,
  has_3yr_budget_projection: boolean,
  has_financial_policy: boolean,
  maturity_score: 0-1
},
int_findings: { financial_data_quality: 0-1 }
```

**Logic:**
- Is org audited/reviewed or unaudited?
- What % goes to admin vs programs? (funder will care)
- Does org have reserves? (signals stability)
- Does org have multi-year financial projection? (signals planning)
- Is funder financially rigorous? (infer from grants, board, practices)

**Example:**
```
Organization: Unaudited (new org, < $500K budget)
Funder: Large foundation, all grantees must be audited

Alignment:
- Org Audit Status: Unaudited
- Funder Requirement: Audited
- Compatibility: 0.0 (automatic disqualification)
- Recommendation: Org must obtain audit before applying
```

**Error Handling:**
- Financial data not available: ask org
- Requirements conflicting: flag for manual review
- New org without audit: flag "will need to address before applying"

**Dependencies:** BEN-DIS-06 (for funder financial context)

---

### BEN-INT-09: Track Record & Credentials Alignment Agent
**Status:** ✅ COMPLETE  
**Purpose:** Assess org's track record vs funder's expectations for proven impact  
**Input:**
- organization: { years_established, major_accomplishments[], awards_recognition[] }
- dis_recent_grantees: from BEN-DIS-04 (what's funder's grantee track record?)

**Output:**
```typescript
int_track_record_strength: 0-1,
int_credentials: {
  years_established: integer,
  major_accomplishments: string[],
  awards_recognition: string[],
  credential_level: "proven"|"developing"|"emerging"|"unproven"
},
int_funder_credential_expectations: "high_bar"|"moderate"|"low"|"unknown",
int_credential_alignment: 0-1,
int_findings: { accomplishment_verification: 0-1 }
```

**Logic:**
- How long has org been operating?
- What major accomplishments can be documented?
- Has org won awards/recognition?
- What track record do funder's grantees have?
- Does org meet funder's unspoken credential bar?

**Example:**
```
Organization: 3 years old, strong outcomes, no major awards yet
Funder: All grantees are 10+ years established with national recognition

Alignment:
- Org Track Record: Solid but young
- Funder Expectations: Proven, established organizations
- Compatibility: 0.3 (org likely doesn't meet funder's bar)
- Recommendation: Org should apply after 5+ years and with award recognition
```

**Error Handling:**
- Accomplishments hard to verify: note as requirement
- Funder's expectations unclear: look at grantee profiles
- Org young: not disqualifying but important context

**Dependencies:** BEN-DIS-04 (needs grantee track record context)

---

### BEN-INT-10: Program Officer Relationship Readiness Agent
**Status:** ✅ COMPLETE  
**Purpose:** Assess if org can build productive relationship with funder's program officer  
**Input:**
- organization: { communication_style, responsiveness, board_engagement }
- sup_decision_makers: from BEN-SUP-06
- dis_board_members: from BEN-DIS-03

**Output:**
```typescript
int_relationship_readiness: 0-1,
int_program_officer_fit: {
  program_officer_name: string,
  program_officer_expertise: string[] (relevant areas),
  likelihood_of_productive_relationship: 0-1,
  potential_connection_points: string[]
},
int_org_responsiveness: "high"|"moderate"|"low"|"unknown",
int_org_communication_professionalism: 0-1,
int_findings: { relationship_readiness_confidence: 0-1 }
```

**Logic:**
- Who is the program officer for relevant grant program?
- What is their background/expertise?
- Are there connection points (alumni, previous employer, shared network)?
- Is org responsive/professional in communication?
- Likelihood of productive working relationship?

**Example:**
```
Program Officer: Jane Smith, Program Director for Housing
Her Background: 15 years in affordable housing, worked for similar nonprofit

Organization: Housing nonprofit, strong communication, professional
Board Member Connection: None identified

Relationship Fit:
- PO Expertise Match: Excellent (housing focus)
- Org Professionalism: High
- Connection Points: None, but not needed (strong expertise match)
- Relationship Readiness: 0.9 (very likely to be productive)
```

**Error Handling:**
- Program officer not identified: flag "need to research further"
- No connection points: not concerning if expertise aligns
- Org professionalism unclear: would become apparent in outreach

**Dependencies:** BEN-SUP-06 (needs PO identity), BEN-DIS-03 (needs board context)

---

## FAMILY 4: REL (Relationships) — 6 Agents

### BEN-REL-01: Known Connections Discovery Agent
**Status:** ✅ COMPLETE  
**Purpose:** Identify existing relationships, connections, prior contacts  
**Input:**
- organization: { board[], staff[], previous_grantors[] }
- prospect: { name }
- sup_decision_makers: from BEN-SUP-06

**Output:**
```typescript
rel_known_connections: [
  {
    connection_type: "board_overlap"|"staff_overlap"|"prior_grant"|"board_connection"|"staff_connection",
    person_name: string,
    org_affiliation: string,
    funder_affiliation: string,
    relationship_strength: 0-1,
    introduction_potential: 0-1 (can this person facilitate introduction?)
  }
],
rel_prior_grants: [
  {
    grant_date: date,
    grant_amount: numeric,
    program: string,
    outcome: "successful"|"not_renewed"|"unknown"
  }
],
rel_relationship_score: 0-1 (0=complete cold, 1=warm existing relationship),
rel_findings: { connection_confidence: 0-1 }
```

**Logic:**
- Does org have board members who sit on funder's board?
- Does org have staff members who previously worked at funder?
- Has org received grants from funder before?
- Are there secondary connections (friend of friend)?

**Example:**
```
Organization Board Member: John Smith
Funder Board: John Smith on board (same person!)

Connection:
- Type: Board overlap
- Strength: 1.0 (perfect relationship)
- Introduction Potential: 1.0 (direct pathway to board)
- Relationship Score: 0.95 (warm introduction, not cold outreach)
```

**Error Handling:**
- Names similar but not identical: verify it's same person
- Prior grant very old: flag "historical but not recent"
- No connections found: relationship is cold (not disqualifying)

**Dependencies:** None (can start with known org info)

---

### BEN-REL-02: Secondary Connection Mapping Agent
**Status:** ✅ COMPLETE  
**Purpose:** Identify second-degree connections through networks  
**Input:**
- organization: { board[], staff[] }
- prospect: { sup_decision_makers, dis_board_members }

**Output:**
```typescript
rel_secondary_connections: [
  {
    intermediate_person: string,
    intermediate_affiliation: string,
    funder_person: string,
    funder_affiliation: string,
    connection_type: "alumni"|"previous_colleague"|"board_connection"|"nonprofit_network"|"donor_circle",
    connection_strength: 0-1,
    introduction_feasibility: "easy"|"moderate"|"difficult"|"unlikely"
  }
],
rel_warm_introduction_possible: boolean,
rel_introduction_path_analysis: [
  {
    path: string (e.g., "Board Member A → Funder Board Member B"),
    strength: 0-1,
    effort_required: "high"|"moderate"|"low"
  }
],
rel_findings: { network_depth: 0-1 }
```

**Logic:**
- Build network graph of org → board/staff
- Build network graph of funder → board/staff
- Find overlaps and connections
- Identify introduction paths
- Assess feasibility of warm introduction

**Example:**
```
Org Board Member: Alice works with Board Member Bob at nonprofit X
Funder Board Member: Bob is on funder's board

Connection:
- Path: Org → Alice → Bob → Funder
- Type: Shared nonprofit network
- Strength: 0.7 (one degree of separation)
- Feasibility: Moderate (requires Alice to make intro)
- Value: Warm introduction is possible via nonprofit network
```

**Error Handling:**
- Network sparse: may have no secondary connections
- Connections exist but weak: flag effort required
- Introduction feasibility unclear: provide multiple options

**Dependencies:** BEN-REL-01 (first map known connections)

---

### BEN-REL-03: Relationship Maturity Assessment Agent
**Status:** ✅ COMPLETE  
**Purpose:** Classify relationship into maturity stage (cold → warm → active → champion)  
**Input:**
- rel_known_connections: from BEN-REL-01
- rel_secondary_connections: from BEN-REL-02
- rel_prior_grants: from BEN-REL-01
- dis_board_members: from BEN-DIS-03

**Output:**
```typescript
rel_relationship_status: "cold"|"warm"|"active"|"champion"|"unknown",
rel_relationship_maturity: {
  stage: "cold"|"warm"|"active"|"champion",
  definition: string,
  indicators: string[],
  next_action: string
},
rel_relationship_score: 0-1 (composite score across all REL data),
rel_warm_introduction_path: string|null (if warm/active/champion),
rel_cold_outreach_strategy: string|null (if cold),
rel_findings: { maturity_confidence: 0-1 }
```

**Stages:**
- **COLD:** No known connections, first contact needed (outreach via general inquiry)
- **WARM:** Secondary connection exists, introduction possible (reach out via intermediary)
- **ACTIVE:** Known board/staff connection or recent grant history (direct relationship exists)
- **CHAMPION:** Board member is organization champion, prior large grant, strong relationship (pre-qualified)

**Logic:**
- Start at COLD
- Upgrade to WARM if secondary connections exist
- Upgrade to ACTIVE if primary connection exists
- Upgrade to CHAMPION if board member on both orgs OR large recent grant
- Calculate composite REL score from all evidence

**Example:**
```
Evidence:
- Secondary connection exists (WARM)
- No primary connections (not ACTIVE)
- No prior grants (not ACTIVE)
- No board champions (not CHAMPION)

Status: WARM
Score: 0.55
Strategy: Warm introduction via secondary connection
Next Action: Ask board member to introduce
```

**Error Handling:**
- Status unclear: use conservative classification (COLD rather than WARM)
- Mixed signals: flag for manual review

**Dependencies:** BEN-REL-01/02 (needs connection data)

---

### BEN-REL-04: Board Member Profile & Influence Agent
**Status:** ✅ COMPLETE  
**Purpose:** Identify org's board members who can influence or open doors with funder  
**Input:**
- organization: { board[] }
- dis_board_members: from BEN-DIS-03
- rel_secondary_connections: from BEN-REL-02

**Output:**
```typescript
rel_board_influencers: [
  {
    board_member_name: string,
    board_member_title: string (at org),
    influence_area: string (where they have sway),
    funder_connection_strength: 0-1 (how connected to funder?),
    influence_type: "board_connection"|"network_connection"|"sector_credibility"|"donor_status",
    likelihood_willing_to_advocate: 0-1,
    recommended_approach: string
  }
],
rel_strongest_internal_advocate: string (board member most likely to champion effort),
rel_findings: { influencer_identification: 0-1 }
```

**Logic:**
- Which board members have most influence?
- Which board members have funder connections?
- Who is most likely to advocate internally for pursuing grant?
- Who should be briefed first?

**Example:**
```
Board Member: Sarah Chen, Tech entrepreneur, sits on multiple boards
- Funder Connection: Sarah's husband is on funder's board
- Influence Type: Board connection + sector credibility
- Likelihood to advocate: High (entrepreneurial, knows she can facilitate)
- Recommended Approach: Brief Sarah first, ask her to facilitate board support + introduce to husband
```

**Error Handling:**
- Board too small to have clear influencers: note all board members equally important
- Influence paths unclear: flag for further research

**Dependencies:** BEN-DIS-03 (needs board profile info), BEN-REL-02 (needs connection strength)

---

### BEN-REL-05: Prior Relationship & Grant History Agent
**Status:** ✅ COMPLETE  
**Purpose:** Analyze past relationships with funder, what went well/poorly, renewal probability  
**Input:**
- organization: { grant_history[] }
- prospect_id: uuid (same funder being researched)

**Output:**
```typescript
rel_prior_relationship: {
  relationship_exists: boolean,
  years_since_last_contact: integer|null,
  total_grants_received: integer,
  total_funding: numeric
},
rel_past_grants: [
  {
    grant_date: date,
    grant_amount: numeric,
    grant_purpose: string,
    program: string,
    grant_outcome: "successful"|"partially_successful"|"not_renewed"|"unknown",
    reason_not_renewed: string|null,
    lessons_learned: string|null
  }
],
rel_renewal_probability: 0-1 (likelihood of repeat funding),
rel_relationship_trajectory: "strengthening"|"stable"|"declining"|"dormant"|"unknown",
rel_findings: { grant_history_completeness: 0-1 }
```

**Logic:**
- Has org received grants from this funder before?
- How many grants? When?
- Were they successful?
- Why was funding stopped (if it was)?
- What's the likelihood of renewing?

**Example:**
```
History:
- 2019: $50K grant for housing program
- 2021: Applied for renewal, rejected (reason: org's outcomes unclear)
- 2023: No contact

Assessment:
- Prior Relationship: Yes
- Grant Outcome: Not renewed (fixable problem)
- Renewal Probability: 0.6 (possible if org addresses outcomes measurement)
- Trajectory: Declining (no contact in 2+ years)
- Recommendation: Org needs to strengthen outcomes before reapproaching
```

**Error Handling:**
- Grant history incomplete: ask organization
- Reasons for decline unclear: may need to call funder
- Long gap since contact: may need to re-introduce

**Dependencies:** Organization grant history (may not be available from external sources)

---

### BEN-REL-06: Relationship Development Roadmap Agent
**Status:** ✅ COMPLETE  
**Purpose:** Create step-by-step relationship-building strategy (cold → warm → submission)  
**Input:**
- rel_relationship_status: from BEN-REL-03
- rel_known_connections: from BEN-REL-01
- rel_secondary_connections: from BEN-REL-02
- rel_prior_relationship: from BEN-REL-05

**Output:**
```typescript
rel_development_roadmap: {
  current_status: "cold"|"warm"|"active"|"champion",
  recommended_timeline: integer (weeks before submission),
  relationship_building_steps: [
    {
      step_number: integer,
      action: string (e.g., "Board member A calls Program Officer Jane"),
      responsible_party: string,
      success_criteria: string,
      timeline: string (e.g., "Week 1")
    }
  ],
  key_milestones: [
    {
      milestone: string (e.g., "Program Officer aware of org"),
      timeline: string,
      success_indicator: string
    }
  ],
  risk_factors: string[],
  contingency_plans: { risk: string, contingency: string }[]
},
rel_submission_readiness_trigger: string (when is org ready to submit?),
rel_findings: { roadmap_confidence: 0-1 }
```

**Example Roadmap for COLD prospect:**
```
Current Status: Cold (no known connections)
Timeline: 8 weeks before submission

Steps:
1. Week 1: Board member conducts LinkedIn research on Program Officer
2. Week 2: Find mutual connection through nonprofit network
3. Week 3: Mutual connection makes warm introduction
4. Week 4: Org has coffee chat with Program Officer (information gathering)
5. Week 5: Program Officer suggests org attend funder's convenings
6. Week 6: Org attends convening, builds relationship
7. Week 7: Program Officer indicates readiness to review proposal
8. Week 8: Submit proposal to Program Officer

Key Milestones:
- "Warm introduction made" (Week 3)
- "Relationship with PO established" (Week 5)
- "Feedback on concept received" (Week 7)

Success Indicator: "PO says 'submit when ready'" by Week 7
```

**Error Handling:**
- Roadmap infeasible: revise timeline
- Key person unavailable: note contingency
- Risk high: flag "proceed with caution"

**Dependencies:** All prior REL agents (comprehensive relationship analysis)

---

## FAMILY 5: QLF (Qualification) — 5 Agents

### BEN-QLF-01: Capacity Estimation Agent
**Status:** ✅ COMPLETE  
**Purpose:** Estimate prospect's financial capacity to fund nonprofit  
**Input:**
- sup_annual_giving_budget: from BEN-SUP-02
- sup_grant_size_range: from BEN-SUP-01
- dis_financial_metrics: from BEN-DIS-06
- dis_recent_grantees: from BEN-DIS-04

**Output:**
```typescript
qlf_capacity_estimate_low: numeric (conservative estimate),
qlf_capacity_estimate_high: numeric (optimistic estimate),
qlf_capacity_score: 0-1 (composite confidence),
qlf_capacity_sources: [
  {
    source: "Form 990-PF assets"|"giving history"|"grant sizes"|"endowment estimate",
    estimate: numeric,
    confidence: 0-1
  }
],
qlf_capacity_evidence: {
  asset_base: numeric|null,
  annual_giving_budget: numeric|null,
  average_grant_size: numeric|null,
  largest_recent_grant: numeric|null
},
qlf_findings: { capacity_estimation_confidence: 0-1 }
```

**Logic:**
- Gather multiple signals: assets, giving history, grant sizes, recent awards
- Cross-reference (should be consistent)
- Produce low/high range with confidence

**Example:**
```
Evidence:
- Form 990-PF shows $500M assets
- 5% distribution rule = $25M annual giving budget
- Average grant: $150K
- Largest recent grant: $500K

Capacity Estimate:
- Conservative (low): $50K-$200K (based on smallest typical grant)
- Optimistic (high): $300K-$500K (based on recent larger grant)
- Most Likely: $100K-$250K
- Score: 0.85 (high confidence based on multiple data sources)
```

**Error Handling:**
- Data contradictory (high assets but low giving): flag discrepancy
- 990-PF not found: use giving history as proxy
- Recent trend down: flag as risk factor

**Dependencies:** BEN-SUP-01/02 (capacity data), BEN-DIS-06 (financial health)

---

### BEN-QLF-02: Eligibility Screening Agent
**Status:** ✅ COMPLETE  
**Purpose:** Determine if nonprofit meets funder's basic eligibility requirements  
**Input:**
- organization: { 501c3_status, years_established, annual_budget, geographic_location, cause_focus }
- dis_compliance_requirements: from BEN-DIS-08

**Output:**
```typescript
qlf_eligibility_status: "eligible"|"likely_eligible"|"unclear"|"ineligible",
qlf_eligibility_assessment: {
  requirement: string (e.g., "Must be 501(c)3"),
  org_status: string (e.g., "IS 501(c)3"),
  compliance: "pass"|"fail"|"uncertain",
  evidence: string
}[],
qlf_disqualifying_factors: string[] (if any),
qlf_conditional_eligibility: string|null (e.g., "If org becomes 501(c)3 within 6 months"),
qlf_findings: { eligibility_confidence: 0-1 }
```

**Logic:**
- Check each requirement against org facts
- Identify pass/fail for each
- Flag any disqualifying factors
- Provide conditional eligibility if applicable

**Example:**
```
Requirements Check:
✅ 501(c)3: Organization IS 501(c)3 → PASS
✅ Years Established: 8 years (requirement 3+ years) → PASS
✅ Nonprofit Status: Verified nonprofit → PASS
❌ Cause Focus: Require education focus, org is housing → FAIL
✅ Geographic: Require Bay Area, org serves SF Bay Area → PASS

Status: INELIGIBLE (education requirement fails)

Unless: Org has education component that wasn't surfaced → UNCLEAR
Recommendation: Org should clarify if they do any education-related work
```

**Error Handling:**
- Requirement unclear: mark as UNCERTAIN
- Org status unknown: ask for documentation
- Multiple disqualifying factors: mark INELIGIBLE with details

**Dependencies:** BEN-DIS-08 (needs compliance requirements)

---

### BEN-QLF-03: Funding Size Match Agent
**Status:** ✅ COMPLETE  
**Purpose:** Match org's funding need/request size with funder's capacity and average grant  
**Input:**
- organization: { annual_budget, specific_project_budget, funding_request_amount }
- qlf_capacity_estimate_low: from BEN-QLF-01
- qlf_capacity_estimate_high: from BEN-QLF-01
- sup_grant_size_range: from BEN-SUP-01

**Output:**
```typescript
qlf_appropriate_ask_range: {
  minimum: numeric (floor that's not insulting to funder),
  maximum: numeric (ceiling that funder can afford),
  optimal: numeric (sweet spot where both benefit),
  reasoning: string
},
qlf_request_size_analysis: {
  org_requested_amount: numeric,
  funder_capacity: numeric,
  funder_avg_grant: numeric,
  alignment: "too_small"|"right_size"|"too_large"|"unknown",
  recommendation: string
},
qlf_findings: { funding_match_confidence: 0-1 }
```

**Logic:**
- What is org's actual funding need?
- What is funder's average grant size?
- What is funder's capacity estimate?
- What ask size makes sense for both parties?

**Example:**
```
Organization Need: $250K for housing program
Funder Capacity: $100K-$300K
Funder Average: $150K
Funder Min Grant: $50K
Funder Max Grant: $500K

Analysis:
- Org Request ($250K): Right in middle of funder range
- Alignment: "Right Size"
- Optimal Ask: $200K-$250K (shows understanding of funder capacity)
- Recommendation: Ask for $225K (signals respect for funder's capacity + leaves room to negotiate down)
```

**Error Handling:**
- Ask too small (< $50K): funder won't bother (ask bigger)
- Ask too large (> funder capacity): automatic decline (reduce ask)
- Org need unclear: ask organization for budgets

**Dependencies:** BEN-QLF-01 (needs capacity), BEN-SUP-01 (needs grant sizes)

---

### BEN-QLF-04: Liquidity & Stability Assessment Agent
**Status:** ✅ COMPLETE  
**Purpose:** Assess funder's liquidity and likelihood of sustainable funding  
**Input:**
- organization: { multi_year_operational_plan, reserves_months }
- dis_financial_metrics: from BEN-DIS-06
- dis_financial_health: from BEN-DIS-06

**Output:**
```typescript
qlf_funder_stability: "highly_stable"|"stable"|"at_risk"|"unknown",
qlf_liquidity_assessment: {
  liquid_assets: numeric|null (cash, marketable securities),
  liquid_asset_ratio: 0-1 (liquid assets / annual distributions),
  assessment: "strong_liquidity"|"adequate_liquidity"|"limited_liquidity"|"unknown"
},
qlf_multi_year_funding_likelihood: 0-1,
qlf_sustainability_risk: "low"|"medium"|"high"|"unknown",
qlf_findings: { stability_assessment_confidence: 0-1 }
```

**Logic:**
- Is funder's endowment growing or shrinking?
- Can funder cover commitments?
- Is funder cutting programs or expanding?
- Likelihood they'll fund for 3+ years?

**Example:**
```
Assessment:
- Endowment: Up 8% last year → Positive
- Liquid Assets: 90% of annual distribution → Strong liquidity
- Trend: Giving increasing → Positive
- Risk Factors: None identified

Stability: HIGHLY STABLE
Multi-Year Likelihood: 0.9 (very likely to continue funding)
```

**Error Handling:**
- Financial data outdated: flag "verify current status"
- Trend unclear: use most recent data
- Risk detected: note as factor in sustainability

**Dependencies:** BEN-DIS-06 (needs financial health data)

---

### BEN-QLF-05: Mission Capacity & Qualification Agent
**Status:** ✅ COMPLETE  
**Purpose:** Assess if org has capacity to execute funded project  
**Input:**
- organization: { staff_size, annual_budget, project_experience, management_capacity }
- dis_recent_grantees: from BEN-DIS-04
- int_scale_alignment: from BEN-INT-05

**Output:**
```typescript
qlf_execution_capacity: 0-1,
qlf_project_management_capacity: {
  staff_experience_with_similar_projects: 0-1,
  project_management_skills: 0-1,
  overall_capacity: 0-1
},
qlf_financial_management_capacity: {
  accounting_sophistication: 0-1,
  audit_status: "audited"|"reviewed"|"unaudited",
  financial_controls: 0-1,
  overall_capacity: 0-1
},
qlf_reporting_capacity: 0-1 (can org provide funder reporting?),
qlf_risk_factors: [
  { factor: string, mitigation: string|null }
],
qlf_findings: { capacity_assessment_confidence: 0-1 }
```

**Logic:**
- Has org run similar programs before?
- Does staff have project management experience?
- Is org audited (financial controls)?
- Can org handle reporting requirements?

**Example:**
```
Assessment:
- Program Experience: Org has run similar housing programs for 8 years
- Project Management: Dedicated program director with 10 years experience
- Financial Audit: Annual audits, clean audit reports
- Reporting: Org tracks outcomes, can provide reports

Capacity: 0.9 (strong execution capacity)
Risk Factors: None identified
```

**Error Handling:**
- Capacity unclear: flag "need to assess during due diligence"
- Weak areas detected: note as conditions for funding (e.g., "require external project manager")

**Dependencies:** BEN-INT-05 (scale context)

---

## FAMILY 6: STR (Strategy/Timing) — 4 Agents

### BEN-STR-01: Optimal Timing & Readiness Agent
**Status:** ✅ COMPLETE  
**Purpose:** Determine when org should submit (now, wait, avoid completely)  
**Input:**
- int_overall_fit_score: from INT family
- qlf_eligibility_status: from BEN-QLF-02
- rel_relationship_status: from BEN-REL-03
- organization: { project_timeline, funding_urgency }

**Output:**
```typescript
str_optimal_contact_time: "immediately"|"within_month"|"in_3_months"|"in_6_months"|"after_fix"|"not_recommended"|"unknown",
str_readiness_score: 0-1,
str_readiness_factors: {
  org_mission_readiness: 0-1 (has org clarified its mission/strategy?),
  relationship_readiness: 0-1 (is relationship at right stage?),
  financial_readiness: 0-1 (do finances meet funder standard?),
  proposal_readiness: 0-1 (can org write strong proposal?),
  project_readiness: 0-1 (is project ready to launch if funded?)
},
str_timing_recommendation: string (e.g., "Contact now via warm intro, funder accepts rolling apps"),
str_findings: { timing_confidence: 0-1 }
```

**Logic:**
- Is org ready to apply today?
- Are there barriers to overcome first?
- Is there urgency?
- What should org do NOW to prepare?

**Example:**
```
Readiness Assessment:
- Mission Clarity: Good (clear focus)
- Relationship: Warm (secondary connection exists)
- Finances: Weak (no audit, needs work)
- Proposal: Unknown (would need to assess)
- Project: Ready (clear plan, timeline)

Timing: "In 3 months" (give org time to get audited)

Recommendation:
1. Get audited (priority) → 8 weeks
2. Develop proposal outline → 4 weeks
3. Make warm introduction → concurrent
4. Submit proposal → week 12
```

**Error Handling:**
- Readiness unclear: recommend assessment before contact
- Multiple barriers: prioritize (which to fix first?)
- Urgent deadline: flag "may need to submit before ready"

**Dependencies:** All INT/QLF/REL data (comprehensive readiness assessment)

---

### BEN-STR-02: Funder Calendar & Deadline Agent
**Status:** ✅ COMPLETE  
**Purpose:** Map funder's deadlines, application cycles, decision timeline  
**Input:**
- sup_application_cycle: from BEN-SUP-05
- dis_recent_announcements: from BEN-DIS-02

**Output:**
```typescript
str_application_deadlines: [
  {
    deadline: date,
    program: string,
    application_window: { open_date: date, close_date: date },
    decision_timeline: integer (days until decision),
    priority_level: "primary"|"secondary"|"tertiary" (how important to org?)
  }
],
str_funding_cycle_type: "rolling"|"annual"|"semi_annual"|"ad_hoc"|"unknown",
str_next_deadline: date|null,
str_application_cycle_analysis: {
  number_of_application_windows: integer,
  deadlines_per_year: integer,
  flexibility: "high"|"moderate"|"low"
},
str_findings: { deadline_clarity: 0-1 }
```

**Logic:**
- When can org actually apply?
- Are deadlines rigid or flexible?
- How many chances per year?
- What's the decision timeline?

**Example:**
```
Funder Deadlines:
1. Spring Round: Deadline Feb 15 → Decision 90 days
2. Fall Round: Deadline Sept 15 → Decision 90 days

Funding Cycle: Annual (2 rounds)
Next Deadline: Sept 15 (6 months away)
Flexibility: Low (fixed deadlines)

Implication: Org must plan for Sept 15 deadline (can't do rolling)
```

**Error Handling:**
- Deadline unclear: flag "call funder for clarification"
- Application cycle changing: flag "verify with funder"
- Multiple programs, different deadlines: organize by priority

**Dependencies:** BEN-SUP-05 (needs application cycle info)

---

### BEN-STR-03: Market & Strategic Positioning Agent
**Status:** ✅ COMPLETE  
**Purpose:** Position org strategically within funder's portfolio (differentiate from competitors)  
**Input:**
- dis_competitor_analysis: from BEN-DIS-04
- int_cause_alignment: from BEN-INT-01
- organization: { unique_differentiator, competitive_advantage }

**Output:**
```typescript
str_market_position: {
  funder_portfolio: "crowded"|"moderately_full"|"underserved",
  org_differentiation: 0-1 (how unique is org vs other grantees?),
  competitive_advantage: string[] (what makes org stand out?),
  positioning_recommendation: string
},
str_positioning_strategy: {
  key_message: string (what should org emphasize to funder?),
  proof_points: string[] (evidence for key message),
  differentiation_angle: string
},
str_findings: { positioning_clarity: 0-1 }
```

**Logic:**
- How crowded is funder's grantee portfolio?
- What's already funded?
- What gap can org fill?
- How should org position itself?

**Example:**
```
Portfolio Analysis:
- Funder funds 20 housing organizations
- Most focus on emergency shelter
- Few focus on permanent supportive housing (PSH)
- Org is PSH specialist → DIFFERENTIATION

Positioning:
- Key Message: "We fill the gap in PSH - org moves people from shelter to stability"
- Proof Point: "82% of participants maintain housing 2+ years"
- Angle: "Strategic portfolio gap filler"

Strategy: Lead with permanent outcomes, not just shelter beds
```

**Error Handling:**
- Market analysis unclear: look at actual grantees
- Org's differentiation weak: need to develop it first

**Dependencies:** BEN-DIS-04 (needs competitor analysis)

---

### BEN-STR-04: Negotiation & Terms Prediction Agent
**Status:** ✅ COMPLETE  
**Purpose:** Predict likely grant terms, conditions, negotiations  
**Input:**
- sup_submission_preferences: from BEN-SUP-05
- dis_recent_grantees: from BEN-DIS-04
- qlf_appropriate_ask_range: from BEN-QLF-03

**Output:**
```typescript
str_expected_grant_terms: {
  funding_mechanism: "project_grant"|"operating_support"|"multiyear"|"capacity_building"|"unknown",
  likely_conditions: string[] (e.g., "must provide annual reports", "board seat required"),
  reporting_requirements: string[] (frequency, format),
  performance_expectations: string[],
  restrictions: string[]
},
str_negotiation_likelihood: {
  terms_flexible: 0-1,
  ask_amount_negotiable: 0-1,
  timeline_negotiable: 0-1
},
str_likely_grant_terms: {
  grant_amount_expected: numeric,
  multiyear_probability: 0-1 (likely multiyear vs one-time?),
  unrestricted_probability: 0-1
},
str_findings: { term_prediction_confidence: 0-1 }
```

**Logic:**
- What terms do similar grantees receive?
- Is funder flexible or rigid?
- What conditions are standard?
- What's negotiable?

**Example:**
```
Term Prediction:
- Funding Type: Project grant (based on similar grants)
- Likely Conditions: Annual progress report + site visit
- Multiyear: Low probability (funder does annual rounds)
- Unrestricted: Medium probability (funder varies)

Negotiation Likely:
- Grant Amount: Somewhat negotiable (±20%)
- Timeline: Not negotiable (hard deadline)
- Conditions: Not negotiable (standard across portfolio)

Expected Terms: $200K one-year project grant + annual reporting + site visit
```

**Error Handling:**
- Terms unclear: ask to look at prior grants/agreements
- Funder's flexibility unclear: plan for worst case (rigid)

**Dependencies:** BEN-DIS-04 (needs grantee analysis), BEN-QLF-03 (ask range)

---

## FAMILY 7: KNW (Knowledge) — 4 Agents

### BEN-KNW-01: Sector Benchmarking Agent
**Status:** ✅ COMPLETE  
**Purpose:** Compare org/funder to sector benchmarks (housing, education, health, etc)  
**Input:**
- organization: { annual_budget, cause_focus, geography }
- sup_cause_priorities: from BEN-SUP-04
- dis_recent_grantees: from BEN-DIS-04

**Output:**
```typescript
know_sector_benchmarks: {
  sector: string (e.g., "housing", "education"),
  org_size_percentile: integer (where org ranks by budget),
  funder_giving_percentile: integer (where funder ranks by giving),
  sector_trends: string[] (e.g., "increasing focus on equity")
},
know_peer_comparison: [
  {
    peer_organization: string,
    similarity_score: 0-1,
    size_comparison: string,
    funding_received: numeric|null,
    relative_success: string
  }
],
know_best_practices: string[] (what are sector leaders doing?),
know_findings: { benchmark_data_quality: 0-1 }
```

**Logic:**
- Look up sector data (housing, education, health, etc)
- Compare org's size/budget to peers
- Identify best practices
- Assess funder's generosity vs sector average

**Example:**
```
Sector: Housing
- Average nonprofit budget: $2M (org is $800K = 40th percentile)
- Average grant size: $150K (funder avg = $150K = exactly average)
- Sector Trend: Increasing focus on PSH (org does PSH = aligned)

Peer Comparison:
- Similar org (PSH focus, $900K budget): Received $100K from funder 2 years ago
- Implication: Org likely to receive $80K-$150K range

Best Practices:
- Top performers: Strong outcome metrics + multiyear plans + community partnerships
- Org Status: Has outcome metrics + multiyear plan + partnerships = aligned
```

**Error Handling:**
- Sector benchmarks outdated: use most recent data
- Peer data limited: note confidence level
- No peer comps: use sector averages

**Dependencies:** Organization profile + BEN-DIS-04 (grantee data)

---

### BEN-KNW-02: Regulatory & Environmental Context Agent
**Status:** ✅ COMPLETE  
**Purpose:** Understand regulatory, policy, economic context affecting funder decisions  
**Input:**
- sup_cause_priorities: from BEN-SUP-04
- dis_recent_announcements: from BEN-DIS-02
- organization: { geography, cause_focus }

**Output:**
```typescript
know_regulatory_environment: {
  jurisdiction: string,
  relevant_laws: string[] (e.g., "Affordable Housing Mandate"),
  regulatory_trend: "favorable"|"neutral"|"unfavorable"|"uncertain",
  funder_likely_response: string
},
know_political_environment: {
  political_climate: string (e.g., "housing as policy priority"),
  funder_alignment: 0-1,
  risk_of_deprioritization: 0-1
},
know_economic_conditions: {
  endowment_impact: string (market conditions affect assets),
  giving_climate: "favorable"|"neutral"|"unfavorable"
},
know_sector_trends: string[] (e.g., "shift toward equity focus"),
know_findings: { context_clarity: 0-1 }
```

**Logic:**
- What regulations affect this sector?
- Is there political support or opposition?
- How is economy affecting giving?
- What are sector trends?

**Example:**
```
Context: Affordable Housing in California
- Regulatory: State mandate for affordable units
- Political: Governor has housing shortage as priority
- Economic: Real estate market strong, foundation endowments up
- Sector Trend: Equity focus (prioritizing communities of color)

Assessment:
- Funder Alignment: Strong (policy tailwinds)
- Risk of Deprioritization: Low (housing is hot topic)
- Implication: Good time to ask (policy momentum)
```

**Error Handling:**
- Context too complex: simplify to key factors
- Predictions uncertain: note "rapidly changing"
- Multiple interpretations: present scenarios

**Dependencies:** Organization profile + BEN-DIS-02 (recent news)

---

### BEN-KNW-03: Funder Strategy & Future Direction Agent
**Status:** ✅ COMPLETE  
**Purpose:** Predict funder's future direction (expansion, contraction, pivot)  
**Input:**
- dis_strategic_shifts: from BEN-DIS-02
- dis_recent_announcements: from BEN-DIS-02
- dis_financial_health: from BEN-DIS-06

**Output:**
```typescript
know_funder_strategy: {
  current_focus: string,
  strategic_direction: "expanding"|"contracting"|"pivoting"|"stable"|"unknown",
  new_priority_areas: string[],
  areas_decreasing_focus: string[]
},
know_future_funding_likelihood: {
  expansion_areas: string[] (where funder likely to fund more),
  contraction_areas: string[] (where funder likely to fund less),
  completely_new_areas: string[] (funder entering new territory?)
},
know_strategic_alignment: 0-1 (is org aligned with funder's future, not just past?),
know_findings: { strategy_prediction_confidence: 0-1 }
```

**Logic:**
- What has funder announced recently?
- Are they expanding certain programs?
- Are they killing programs?
- Are they pivoting strategy?
- Will org fit funder's future?

**Example:**
```
Recent Announcements:
- CEO said "expanding climate focus"
- New program launched: "Climate resilience in low-income communities"
- $2M budget increase for climate

Assessment:
- Strategic Direction: Expanding (climate is new priority)
- New Areas: Climate resilience, clean energy, adaptation
- Org Alignment: If housing org has "climate resilience" angle = aligned
- Future Likelihood: High (org entering funder's hot area)

Implication: NOW is time to position org around climate + housing connection
```

**Error Handling:**
- Strategy unclear: look at budget changes + recent hires
- Contradictory signals: note discrepancy, use multiple data points
- Prediction confidence low: flag as "uncertain"

**Dependencies:** BEN-DIS-02/06 (strategy + financial signals)

---

### BEN-KNW-04: Competitive Intelligence & Funder's Priorities Agent
**Status:** ✅ COMPLETE  
**Purpose:** What does funder ACTUALLY care about (vs what they SAY they care about)?  
**Input:**
- dis_recent_grantees: from BEN-DIS-04
- dis_recent_announcements: from BEN-DIS-02
- int_cause_alignment: from BEN-INT-01

**Output:**
```typescript
know_actual_priorities: [
  {
    priority: string (what funder ACTUALLY funds),
    stated_priority: string|null (what they SAY they fund),
    evidence: string[] (grantees, grant amounts),
    funding_level: integer (count of grants, total $)
  }
],
know_values_demonstrated: string[] (what funder actually values: equity, innovation, etc),
know_priority_gaps: [
  {
    stated_but_not_funded: string (funder says but doesn't fund),
    reason: string|null (why gap exists?),
    org_implication: string
  }
],
know_findings: { priority_clarity: 0-1 }
```

**Logic:**
- What does funder's grant portfolio actually show?
- Are stated priorities reflected in grants?
- Are there gaps?
- What ARE the actual priorities?

**Example:**
```
Analysis:
Funder Says: "We support education for low-income youth"
Actual Grantees: 
- 5 orgs do college prep (80% of grants)
- 3 orgs do K-12 (15% of grants)
- 1 org does adult education (5% of grants)

Actual Priorities:
1. College prep programs (STRONG emphasis)
2. K-12 education (WEAK emphasis)
3. Adult ed (MINIMAL emphasis)

Gap: Funder says "education" but actually means "college prep"

Implication: Org should pitch college prep angle, not general education
```

**Error Handling:**
- Limited grantee data: note confidence level
- Recent changes in strategy: use latest grants
- Contradiction between stated/actual: flag as negotiation point

**Dependencies:** BEN-DIS-04 (needs actual grantee data)

---

## FAMILY 8: OPS (Operations) — 1 Agent

### BEN-OPS-01: Application Feasibility & Resource Planning Agent
**Status:** ✅ COMPLETE  
**Purpose:** Assess effort required to apply (time, resources, difficulty)  
**Input:**
- sup_submission_preferences: from BEN-SUP-05
- dis_tech_stack: from BEN-DIS-07
- sup_required_documents: from BEN-SUP-05

**Output:**
```typescript
ops_submission_difficulty: "simple"|"moderate"|"complex"|"very_complex",
ops_estimated_effort_hours: numeric (total staff time to prepare),
ops_effort_breakdown: {
  proposal_writing: integer (hours),
  materials_gathering: integer (hours),
  internal_review: integer (hours),
  formatting: integer (hours),
  submission: integer (hours)
},
ops_required_resources: string[] (staff, external help, tools),
ops_pre_submission_checklist: [
  {
    item: string,
    status: "ready"|"in_progress"|"not_started",
    effort_to_complete: integer (hours)
  }
],
ops_submission_method_ease: 0-1 (online easy, paper hard),
ops_findings: { feasibility_confidence: 0-1 }
```

**Logic:**
- Is submission online or paper?
- What documents required?
- Does funder have template/guidelines?
- How complex is proposal?
- Can org do this with internal staff?

**Example:**
```
Assessment:
- Submission: Online (easy)
- Documents: LOI + 5-page proposal + budget + board list = standard
- Proposal Length: 5 pages (reasonable)
- Special Requirements: None

Effort Estimate:
- Proposal writing: 8 hours
- Materials: 2 hours
- Review: 4 hours
- Submission: 1 hour
- TOTAL: 15 hours (~2 staff days)

Difficulty: SIMPLE (online submission, standard docs, reasonable length)

Resource: In-house staff can handle, no consultant needed
```

**Error Handling:**
- Requirements unclear: add contingency hours
- Org capacity low: budget for consultant
- Complex submission: add support

**Dependencies:** BEN-SUP-05/07 (submission preferences + tech)

---

## FAMILY 9: APP (Application) — 3 Agents

### BEN-APP-01: Application Profile Orchestrator
**Status:** ✅ COMPLETE (see Queue 1 detailed spec)  
**Output:** Complete recommendation of which prospect to pursue, with success probability and strategy

### BEN-APP-02: Recommendation Priority Scorer
**Status:** ✅ COMPLETE (see Queue 1 detailed spec)  
**Output:** Ranked list of prospects by strategic priority

### BEN-APP-03: Submission Orchestrator
**Status:** ✅ COMPLETE (see Queue 1 detailed spec)  
**Output:** Executable submission queue for AutoApply

---

## AGENT DEPENDENCY GRAPH

```
SUP-01 (Entity Verification)
  ↓
SUP-02 (Capacity) ← DIS-01/06 (Web Discovery, Financial Health)
  ↓
SUP-03 (Grant Programs)
  ↓
SUP-04 (Geographic/Cause) ← DIS-04 (Competitor Analysis)
  ↓
SUP-05 (Submission Guidelines)
  ↓
SUP-06 (Contacts) ← DIS-03 (Board Analysis)

DIS-01 (Web Discovery)
  ↓
DIS-02 (Recent News)
  ↓
DIS-03 (Board Analysis)
  ↓
DIS-04 (Competitor Analysis) ← SUP-04
  ↓
DIS-05 (Sentiment/Reputation)
  ↓
DIS-06 (Financial Health)
  ↓
DIS-07 (Tech Stack) ← SUP-05
  ↓
DIS-08 (Risk/Compliance) ← DIS-05

INT-01 (Mission Alignment) ← SUP-04, DIS-04
  ↓
INT-02 (Geographic Alignment) ← SUP-04
  ↓
INT-03 (Strategy Alignment) ← DIS-02, DIS-05, DIS-04
  ↓
INT-04 (Population Alignment) ← SUP-04
  ↓
INT-05 (Scale Alignment) ← SUP-03
  ↓
INT-06 (Theory of Change) ← DIS-05
  ↓
INT-07 (Cultural Alignment) ← DIS-03, DIS-05
  ↓
INT-08 (Financial Alignment) ← DIS-06
  ↓
INT-09 (Track Record) ← DIS-04
  ↓
INT-10 (Relationship Readiness) ← SUP-06, DIS-03

REL-01 (Known Connections)
  ↓
REL-02 (Secondary Connections) ← REL-01
  ↓
REL-03 (Relationship Maturity) ← REL-01, REL-02, REL-01 (prior grants), DIS-03
  ↓
REL-04 (Board Influencers) ← DIS-03, REL-02
  ↓
REL-05 (Prior Relationship) ← Organization history (external)
  ↓
REL-06 (Development Roadmap) ← REL-03, REL-01, REL-02, REL-05

QLF-01 (Capacity) ← SUP-02, SUP-01, DIS-06, DIS-04
  ↓
QLF-02 (Eligibility) ← DIS-08
  ↓
QLF-03 (Funding Size Match) ← QLF-01, SUP-01, QLF-01
  ↓
QLF-04 (Liquidity/Stability) ← DIS-06
  ↓
QLF-05 (Execution Capacity) ← DIS-04, INT-05

STR-01 (Optimal Timing) ← INT (overall), QLF-02, REL-03, Organization readiness
  ↓
STR-02 (Deadlines) ← SUP-05, DIS-02
  ↓
STR-03 (Positioning) ← DIS-04, INT-01
  ↓
STR-04 (Negotiation/Terms) ← SUP-05, DIS-04, QLF-03

KNW-01 (Sector Benchmarking) ← Organization profile, DIS-04
  ↓
KNW-02 (Regulatory Context) ← SUP-04, DIS-02, Organization profile
  ↓
KNW-03 (Funder Strategy) ← DIS-02, DIS-06
  ↓
KNW-04 (Actual Priorities) ← DIS-04, DIS-02, INT-01

OPS-01 (Feasibility) ← SUP-05, DIS-07

APP-01 (Orchestrator) ← All 44 prior agents
  ↓
APP-02 (Prioritizer) ← APP-01
  ↓
APP-03 (Submission) ← APP-02
```

---

## SUMMARY STATISTICS

| Category | Count |
|----------|-------|
| Total Agents | 47 |
| SUP Family | 6 |
| DIS Family | 8 |
| INT Family | 10 |
| REL Family | 6 |
| QLF Family | 5 |
| STR Family | 4 |
| KNW Family | 4 |
| OPS Family | 1 |
| APP Family | 3 |
| Total Output Fields (dossier) | 80+ |
| Total Data Sources | 25+ |
| Agents Reading from SUP | 16 |
| Agents Reading from DIS | 22 |
| Agents Reading from INT | 8 |
| Agents Reading from REL | 6 |
| Agents Reading from QLF | 3 |
| Agents Reading from STR | 2 |
| Agents Reading from KNW | 1 |

---

## ARCHITECTURE NOTES

- **Domain-agnostic design:** Agents use abstract entity types (PERSON, COMPANY, FOUNDATION, NONPROFIT, etc), not hardcoded for nonprofits
- **Tenant isolation:** All agents respect `tenant_id`, no cross-org data leakage
- **Composable:** Each agent can be run independently or as part of pipeline
- **Extensible:** New entity types or scoring dimensions can be added without modifying agents
- **Evidence-driven:** All claims trace back to evidence chain (source, confidence, recency)
- **Error handling:** Graceful degradation when data unavailable (mark as "unknown" not crash)
- **Confidence scoring:** Every output includes 0-1 confidence, not false certainty

---

**[END OF PIL_AGENT_COMPLETE_ROSTER]**
